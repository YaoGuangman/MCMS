﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Page.master" AutoEventWireup="true"
    CodeBehind="NoteBook.aspx.cs" Inherits="MCMS.WebForm11" %>

<%@ Register Src="UserControl/Pages/NoteBook.ascx" TagName="NoteBook" TagPrefix="uc1" %>
<asp:Content ID="Content2" ContentPlaceHolderID="WebSiteHead" runat="server">
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="content_title">
        <strong>留言板</strong>
    </div>
    <div class="content_body">
        <uc1:NoteBook ID="NoteBook1" runat="server" />
    </div>
</asp:Content>

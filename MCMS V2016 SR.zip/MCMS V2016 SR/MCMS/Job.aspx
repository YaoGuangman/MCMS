﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Page.master" AutoEventWireup="true"
    CodeBehind="Job.aspx.cs" Inherits="MCMS.WebForm7" %>

<%@ Register Src="UserControl/Pages/Job.ascx" TagName="Job" TagPrefix="uc1" %>
<asp:Content ID="Content2" ContentPlaceHolderID="WebSiteHead" runat="server">
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="content_title">
        <strong>招聘信息</strong>
    </div>
    <div class="content_body">
        <uc1:Job ID="Job1" runat="server" />
    </div>
</asp:Content>

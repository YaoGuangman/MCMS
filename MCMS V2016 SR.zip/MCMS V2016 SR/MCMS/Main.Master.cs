﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS
{
    public partial class Main : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //读取cookie,如果用户保存了登录信息则自动登录且保存到session
            if (Request.Cookies["UserName"] != null)
            {
                //保存用户信息为缓存
                Session["UserName"] = Request.Cookies["UserName"].Value;
                Session["UserPwd"] = Request.Cookies["UserPwd"].Value;
            }

            //获取网站主标题,副标题，动态更换网站名称
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
            string SQL = "SELECT 主标题 FROM [Style]";
            string webName = cd.GetFirstValue(SQL).ToString();//获取网站主标题
            SQL = "SELECT 副标题 FROM [Style]";
            string webName2 = cd.GetFirstValue(SQL).ToString();//获取网站副标题
            MyTitle.Text = webName + webName2;//动态更换网站名称

            //获取css文件地址,动态更改css
            SQL = "SELECT 主题风格 FROM [Style]";
            string cssFilePath = cd.GetFirstValue(SQL).ToString();
            cssFilePath = "UI" + cssFilePath;//全路径
            cssFilePath = cssFilePath.Replace("\\", "/");
            MyLink.Href = cssFilePath;//清除原有链接

            //获取设置网站关键字
            SQL = "SELECT 关键字 FROM [Style]";
            string keyWord = cd.GetFirstValue(SQL).ToString();
            MyKeyword.Content = keyWord;

            //获取设置网站说明文字
            SQL = "SELECT 说明文字 FROM [Style]";
            string description = cd.GetFirstValue(SQL).ToString();
            MyDescription.Content = description;
        }
    }
}
﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Page.master" AutoEventWireup="true"
    CodeBehind="News.aspx.cs" Inherits="MCMS.WebForm2" %>

<%@ Register Src="UserControl/Pages/News.ascx" TagName="News" TagPrefix="uc1" %>
<asp:Content ID="Content2" ContentPlaceHolderID="WebSiteHead" runat="server">
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="content_title">
        <strong>新闻动态</strong>
    </div>
    <div class="content_body">
        <uc1:News ID="News1" runat="server" />
    </div>
</asp:Content>

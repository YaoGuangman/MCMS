﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.WebControl
{
    public partial class Logo : System.Web.UI.UserControl
    {
        /// <summary>
        /// 获取Logo图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //获取原始的数据到输入框中
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

            string SQL = "SELECT LOGO FROM [Style]";
            string logoName= cd.GetFirstValue(SQL).ToString();

            Image1.ImageUrl = "~/Picture/Logo/" + logoName;
        }
    }
}
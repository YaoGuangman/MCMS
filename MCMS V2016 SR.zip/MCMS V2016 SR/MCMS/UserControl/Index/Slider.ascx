﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Slider.ascx.cs" Inherits="MCMS.UserControl.Index.Slider" %>

<!-- start slideshow -->
<link rel="stylesheet" type="text/css" href="/Slider/Slider.css" media="screen" />
<script type="text/javascript" src="/Slider/Slider.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#slideshow').cycle({
            fx: 'fade',
            speed: 'slow',
            timeout: 3000,
        });
    });
</script>
<!--/slider -->

<!-- start slideshow -->
<div id="slideshow">
    <asp:Repeater ID="Repeater1" runat="server" DataSourceID="AccessDataSource1">
        <ItemTemplate>
            <a href="<%#Eval("链接地址") %>">
                <img class="slideshow_img" src="/Picture/Slider/<%#Eval("图片地址") %>" alt="<%#Eval("链接地址") %>" border="0" />
            </a>
        </ItemTemplate>
    </asp:Repeater>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb" SelectCommand="SELECT * FROM [Slider] ORDER BY [Slider_ID] DESC"></asp:AccessDataSource>
</div>
<!--/slider -->




﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Foot.ascx.cs" Inherits="MCMS.UserControl.Foot" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div id="control_foot">
    <asp:Label ID="Label1" runat="server" Text="[显示底部信息]"></asp:Label>
</div>

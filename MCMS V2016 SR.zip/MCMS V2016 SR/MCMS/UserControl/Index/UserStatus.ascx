﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="UserStatus.ascx.cs" Inherits="MCMS.UserStatus" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div id="control_status">
    <nobr>
     <asp:LinkButton ID="LinkButton1" runat="server" PostBackUrl="/Register/Login.aspx">会员登陆</asp:LinkButton>&nbsp;
     <asp:LinkButton ID="LinkButton3" runat="server" PostBackUrl="/Register/UserInfo.aspx">个人中心</asp:LinkButton>&nbsp;
     <asp:LinkButton ID="LinkButton2" runat="server" PostBackUrl="/Register/CreateUser.aspx">注册会员</asp:LinkButton>&nbsp;
     <asp:LinkButton ID="LinkButton4" runat="server" onclick="LinkButton4_Click">注销登陆</asp:LinkButton>
  </nobr>
</div>

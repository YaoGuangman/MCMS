﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Type.ascx.cs" Inherits="MCMS.UserControl.Default.Type" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_left">
    <asp:DataList ID="DataList2" runat="server" DataSourceID="AccessDataSource1" RepeatColumns="1"
        CellSpacing="9" Height="100%" Width="100%" Font-Bold="True">
        <ItemStyle Height="24px" />
        <ItemTemplate>
            <img alt="" src="/Images/Article.gif" />&nbsp;
            <a href="/Case_Search.aspx?id=<%#Eval("Type_ID") %>">
                <%#Eval("所属项目") %>
            </a>
        </ItemTemplate>
    </asp:DataList>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [Case_Type] ORDER BY [Type_ID] DESC"></asp:AccessDataSource>
</div>

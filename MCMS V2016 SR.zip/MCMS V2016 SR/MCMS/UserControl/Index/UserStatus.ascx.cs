﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS
{
    public partial class UserStatus : System.Web.UI.UserControl
    {
        /// <summary>
        /// 显示登陆状态
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //读取cookie,如果用户保存了登录信息则登录
            if (Session["UserName"]!= null)
            {
                //显示隐藏按钮
                LinkButton1.Visible = false;
                LinkButton2.Visible = false;
                LinkButton3.Visible = true;
                LinkButton4.Visible = true;
            }
            else
            {
                //显示隐藏按钮
                LinkButton3.Visible = false;
                LinkButton4.Visible = false;
                LinkButton1.Visible = true;
                LinkButton2.Visible = true;
            }
        }

        /// <summary>
        /// 注销
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            //删除cookie
            Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(-8);
            Response.Cookies["UserName"].Value  = null;
            Response.Cookies["UserPwd"].Expires = DateTime.Now.AddDays(-8);
            Response.Cookies["UserPwd"].Value = null;
            //更新session
            Session["UserName"] = null;
            Session["UserPwd"] = null;
            Response.Redirect("~/Register/Login.aspx");//跳转到登录
        }
    }
}
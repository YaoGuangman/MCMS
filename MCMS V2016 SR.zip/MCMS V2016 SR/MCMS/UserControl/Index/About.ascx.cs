﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.UserControl
{
    public partial class Introduce : System.Web.UI.UserControl
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        /// <summary>
        /// 字符截取方法
        /// </summary>
        /// <param name="sInput"></param>
        /// <returns></returns>
        public string Intercept(string sInput)
        {
            if (trimLenth != 0)
            {
                if (sInput != null && sInput != string.Empty)
                {
                    //判断是否截取
                    sInput = OperateHtml.ClearHtmlTag(sInput);//去除标签
                    if (sInput.Length > trimLenth)
                    {
                        
                        return sInput = "&nbsp;&nbsp;&nbsp;&nbsp; " + sInput.Substring(0, trimLenth) + "......";
                    }
                    else
                    {
                        return "&nbsp;&nbsp;&nbsp;&nbsp; " + sInput;
                    }
                }
                return "";
            }
            return sInput;
        }

        private int trimLenth = 0;//截取长度

        /// <summary>
        /// 设置截取的尺寸
        /// </summary>
        public int TrimLenth
        {
            get { return trimLenth; }
            set { trimLenth = value; }
        }
    }
}
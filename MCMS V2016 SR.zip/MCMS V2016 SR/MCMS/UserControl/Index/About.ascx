﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="About.ascx.cs" Inherits="MCMS.UserControl.Introduce" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_right">
    <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" DataKeyNames="Style_ID"
        DataSourceID="AccessDataSource1" EnableModelValidation="True" GridLines="None"
        Height="100%" ShowHeader="False" Width="100%" AllowPaging="True" PageSize="1">
        <Columns>
            <asp:TemplateField>
                <ItemTemplate>
                    <%# Intercept(Eval("关于我们").ToString ())%>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <PagerSettings Visible="False" />
    </asp:GridView>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [Style]"></asp:AccessDataSource>
</div>

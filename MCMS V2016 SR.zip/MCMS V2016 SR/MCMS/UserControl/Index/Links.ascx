﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Links.ascx.cs" Inherits="MCMS.UserControl.Links" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_right">
    <asp:DataList ID="DataList1" runat="server" DataKeyField="Links_ID" DataSourceID="AccessDataSource1"
        RepeatColumns="6" Width="100%" RepeatDirection="Horizontal" CellSpacing="3">
        <ItemStyle Height="30px" HorizontalAlign="Center" />
        <ItemTemplate>
            <a href="<%# Eval("链接地址") %>" target="_blank">
                <%# Eval("名称") %>
            </a>
        </ItemTemplate>
    </asp:DataList>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [Links] ORDER BY [Links_ID] DESC"></asp:AccessDataSource>
</div>

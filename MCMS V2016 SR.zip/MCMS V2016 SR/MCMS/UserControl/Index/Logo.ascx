﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Logo.ascx.cs" Inherits="MCMS.WebControl.Logo" %>

<asp:Image ID="Image1" runat="server" Style="height: 60px; margin-top: 20px;" ImageUrl="~/Logo/Logo.gif" />

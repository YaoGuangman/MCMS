﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="News.ascx.cs" Inherits="MCMS.UserControl.Default.News" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_left">
    <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" DataKeyNames="News_ID"
        DataSourceID="AccessDataSource1" EnableModelValidation="True" Height="100%" Width="100%"
        GridLines="None" ShowHeader="False" AllowPaging="True">
        <Columns>
            <asp:TemplateField>
                <ItemTemplate>
                    <div class="control_news_item">
                        <img src="/Images/fast.gif" />
                        <a href="/News_Body.aspx?id=<%#Eval("News_ID") %>">
                            <%# Intercept(Eval("标题").ToString(),16)%>
                        </a>
                    </div>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <PagerSettings FirstPageText="首页" LastPageText="尾页" Mode="NextPreviousFirstLast"
            NextPageText="下一页" PreviousPageText="上一页" Visible="False" />
        <RowStyle Height="0px" />
    </asp:GridView>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [News] ORDER BY [News_ID] DESC"></asp:AccessDataSource>
</div>

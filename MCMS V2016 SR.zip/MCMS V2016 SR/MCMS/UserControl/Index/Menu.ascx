﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Menu.ascx.cs" Inherits="MCMS.UserControl.Menu" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div id="control_menu">
    <ul>
        <li><a href="/Default.aspx">网站首页</a></li>
        <li><a href="/About.aspx">公司简介</a></li>
        <li><a href="/News.aspx">新闻动态</a></li>
        <li><a href="/Case.aspx">产品展示</a></li>
        <li><a href="/Job.aspx">人才招聘</a></li>
        <li><a href="/NoteBook.aspx">在线交流</a></li>
        <li><a href="/Content.aspx">联系我们</a></li>
    </ul>
</div>

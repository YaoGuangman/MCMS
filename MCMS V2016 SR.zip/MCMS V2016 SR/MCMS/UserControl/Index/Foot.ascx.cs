﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.UserControl
{
    public partial class Foot : System.Web.UI.UserControl
    {
        /// <summary>
        /// 获取底部信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //获取原始的数据到输入框中
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

            string SQL = "SELECT 底部信息 FROM [Style]";
            string strFoot = cd.GetFirstValue(SQL).ToString();

            Label1.Text = strFoot;
        }
    }
}
﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Case.ascx.cs" Inherits="MCMS.UserControl.Default.Case" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_right">
    <asp:DataList ID="DataList1" runat="server" DataSourceID="AccessDataSource1" RepeatColumns="4" Height="100%" Width="100%" RepeatDirection="Horizontal" CellPadding="0" CellSpacing="8">
        <ItemTemplate>
            <div class="control_item">
                <a href="/Case_Body.aspx?id=<%#Eval("Case_ID") %>">
                    <img alt="<%#Eval ("标题") %>" src="/Picture/CasePic/<%#Eval("图片地址") %>" style="border-style: none; border-color: inherit; border-width: 0px; height: 119px; width: 150px; margin: 10px;" />
                </a>
            </div>
            <div class="control_item" style="text-align: center;">
                <a href="/Case_Body.aspx?id=<%#Eval("Case_ID") %>">
                    <%#Intercept(Eval("标题").ToString(),12)%>
                </a>
            </div>
            <div class="control_item" style="text-align: center;">
                分类：<%#Intercept(Eval("所属项目").ToString(),12)%></div>
        </ItemTemplate>
    </asp:DataList>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT TOP 12 * FROM [Case_Type_View] ORDER BY [Case_ID] DESC"></asp:AccessDataSource>
</div>

﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Job_Body.ascx.cs" Inherits="MCMS.UserControl.JobBody" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_right">
    <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" DataKeyNames="Job_ID"
        DataSourceID="AccessDataSource1" EnableModelValidation="True" AllowPaging="True"
        PageSize="1" Width="100%" GridLines="None" ShowHeader="False">
        <Columns>
            <asp:TemplateField>
                <ItemTemplate>
                    <div class="control_item" style="text-align: right">
                        <a href="Job_Add.aspx?id=<%#Eval("Job_ID") %>"><b>[我要面试]</b></a>
                    </div>
                    <div class="control_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #808080; font-weight: bold;">
                        职位：
                    </div>
                    <div class="control_item">
                        <%#Eval("职位名称") %>
                    </div>
                    <div class="control_item">
                        &nbsp;
                    </div>
                    <div class="control_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #808080; font-weight: bold;">
                        职位介绍：
                    </div>
                    <div class="control_item">
                        <%#Eval("职位介绍") %>
                    </div>
                    <div class="control_item" style="text-align: right">
                        有效期至：<%#Eval("有效日期") %>&nbsp;&nbsp;职位编号：<%#Eval("Job_ID") %>
                    </div>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <PagerSettings Visible="False" />
    </asp:GridView>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [Job] WHERE ([Job_ID] = ?)">
        <SelectParameters>
            <asp:QueryStringParameter Name="Job_ID" QueryStringField="id" Type="Int32" />
        </SelectParameters>
    </asp:AccessDataSource>
</div>

﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="News.ascx.cs" Inherits="MCMS.UserControl.News" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_right">
    <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" DataKeyNames="News_ID"
        DataSourceID="AccessDataSource1" EnableModelValidation="True" Height="100%" Width="100%"
        GridLines="None" ShowHeader="False" AllowPaging="True" PageSize="35" CellSpacing="5">
        <Columns>
            <asp:TemplateField>
                <ItemTemplate>
                    <div class="control_news_item">
                        <img src="/Images/fast.gif" />
                        <a href="/News_Body.aspx?id=<%#Eval("News_ID") %>">
                            <%# Eval("标题")%>
                        </a>
                    </div>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <PagerSettings FirstPageText="首页" LastPageText="尾页" Mode="NextPreviousFirstLast"
            NextPageText="下一页" PreviousPageText="上一页" />
        <PagerStyle BackColor="#DDDDFF" Font-Bold="True" Height="45px" />
        <RowStyle Height="40px" />
    </asp:GridView>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [News] ORDER BY [News_ID] DESC"></asp:AccessDataSource>
</div>

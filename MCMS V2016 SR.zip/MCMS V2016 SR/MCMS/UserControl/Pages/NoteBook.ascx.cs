﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.UserControl
{
    public partial class NoteBook : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 字符截取方法
        /// </summary>
        /// <param name="sInput"></param>
        /// <returns></returns>
        public string Intercept(string sInput)
        {
            if (sInput != null && sInput != string.Empty)
            {
                if (sInput.Length > 255)
                    return sInput = sInput.Substring(0, 255) + "";
                else
                    return sInput;
            }
            return "";
        }

        /// <summary>
        /// 提交回复
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Session["UserName"] != null && Session["UserPwd"] != null)
            {
                //获取昵称
                string UserName = Session["UserName"].ToString();
                CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

                string SQL = "SELECT 昵称 FROM [User] WHERE (User_Name = '" + UserName + "')";
                string name = cd.GetFirstValue(SQL).ToString();

                //截取字符串
                string str = TextBox2.Text;
                if (str.Length >= 200)
                {
                    str = str.Substring(0, 200);
                }

                SQL = "INSERT INTO Notebook (标题, 昵称, 正文, 发布日期) VALUES   ('" +
                    TextBox1.Text.Trim() + "', '" +
                    name + "', '" +
                    str + "', '" +
                    DateTime.Now.ToString() + "')";

                cd.RunSqlCmd(SQL);

                Response.Redirect("~/Notebook.aspx");
            }
            else
            {
                //跳转到指定页面
                Session["GotoURL"] = "~/Register/Login.aspx";
                Session["Info"] = "对不起，您目前为游客，请返回登录";
                Response.Redirect("~/Register/MessageBox.aspx");
            }
        }
    }
}
﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Job.ascx.cs" Inherits="MCMS.UserControl.Job" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_right">
    <asp:GridView ID="GridView1" runat="server" AllowPaging="True" AutoGenerateColumns="False"
        DataKeyNames="Job_ID" DataSourceID="AccessDataSource1" EnableModelValidation="True"
        GridLines="None" Width="100%" BorderColor="#336666" BorderStyle="None" CellPadding="3"
        ShowHeader="False" PageSize="8">
        <Columns>
            <asp:TemplateField>
                <ItemTemplate>
                    <div class="control_job">
                        <div class="control_item">
                            <strong>职位名称：<%#Eval("职位名称") %></strong>
                        </div>
                        <div class="control_item">
                            <%#Intercept(Eval("职位介绍").ToString(),260)%>&nbsp;&nbsp;......
                        </div>
                        <div class="control_item" style="text-align: right">
                            <a href="Job_Body.aspx?id=<%#Eval("Job_ID") %>"><b>[查看详情]</b></a>
                            &nbsp; 
                            <a href="Job_Add.aspx?id=<%#Eval("Job_ID") %>"><b>[我要面试]</b></a>
                        </div>
                    </div>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <PagerSettings FirstPageText="首页" LastPageText="尾页" Mode="NextPreviousFirstLast"
            NextPageText="下一页" PreviousPageText="上一页" />
        <PagerStyle BackColor="#DDDDFF" Font-Bold="True" Height="45px" />
    </asp:GridView>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [Job] ORDER BY [有效日期] DESC"></asp:AccessDataSource>
</div>

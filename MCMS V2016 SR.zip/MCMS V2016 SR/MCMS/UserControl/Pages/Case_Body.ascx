﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Case_Body.ascx.cs" Inherits="MCMS.UserControl.CaseBody" %>
<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_right">
    <asp:GridView ID="GridView1" runat="server" EnableModelValidation="True" AllowPaging="True"
        GridLines="None" PageSize="1" Width="100%" DataSourceID="AccessDataSource1" AutoGenerateColumns="False"
        DataKeyNames="Case_ID" ShowHeader="False">
        <Columns>
            <asp:TemplateField>
                <ItemTemplate>
                    <div class="control_casebody_title">
                        产品名称：<%# Eval("标题") %>
                    </div>
                    <div class="control_casebody_item">
                        <img alt="<%#Eval("标题") %>" src="/Picture/CasePic/<%#Eval("图片地址") %>" style="width: 730px;" />
                    </div>
                    <div class="control_casebody_item">
                        <b>产品编号：</b><%# Eval("Case_ID") %>
                    </div>
                    <div class="control_casebody_item">
                        <b>发布日期：</b><%# Eval("发布日期") %>
                    </div>
                    <div class="control_casebody_item">
                        <b>产品分类：</b><%# Eval("所属项目") %>
                    </div>
                    <div class="control_casebody_item">
                        <b>备注信息：</b><%# Eval("备注") %>
                    </div>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <PagerSettings Visible="False" />
    </asp:GridView>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [Case_Type_View] WHERE ([Case_ID] = ?)">
        <SelectParameters>
            <asp:QueryStringParameter Name="Case_ID" QueryStringField="id" Type="Int32" />
        </SelectParameters>
    </asp:AccessDataSource>
</div>

﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Job_Add.ascx.cs" Inherits="MCMS.UserControl.Job_Add" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_right">
    <div class="control_item">
        <div class="control_item_left">
            姓名：
        </div>
        <div class="control_item_right">
            <asp:TextBox ID="TextBox1" runat="server" MaxLength="10"></asp:TextBox>
            *<asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="TextBox1"
                ErrorMessage="姓名不能为空"></asp:RequiredFieldValidator>
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            性别：
        </div>
        <div class="control_item_right">
            <asp:RadioButton ID="RadioButton1" runat="server" Checked="True" GroupName="A" Text="男" />
            &nbsp;&nbsp;<asp:RadioButton ID="RadioButton2" runat="server" GroupName="A" Text="女" />
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            年龄：
        </div>
        <div class="control_item_right">
            <asp:TextBox ID="TextBox2" runat="server" MaxLength="3"></asp:TextBox>
            *<asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" ControlToValidate="TextBox2"
                ErrorMessage="年龄不能为空"></asp:RequiredFieldValidator>
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            电话：
        </div>
        <div class="control_item_right">
            <asp:TextBox ID="TextBox6" runat="server" MaxLength="20"></asp:TextBox>
            *<asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ControlToValidate="TextBox6"
                ErrorMessage="电话不能为空"></asp:RequiredFieldValidator>
            &nbsp;</div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            学历：
        </div>
        <div class="control_item_right">
            <asp:DropDownList ID="DropDownList1" runat="server" Width="149px">
                <asp:ListItem>博士</asp:ListItem>
                <asp:ListItem Value="硕士"></asp:ListItem>
                <asp:ListItem>研究生</asp:ListItem>
                <asp:ListItem>本科</asp:ListItem>
                <asp:ListItem>大专</asp:ListItem>
                <asp:ListItem>中专</asp:ListItem>
                <asp:ListItem>技校</asp:ListItem>
                <asp:ListItem>高中</asp:ListItem>
                <asp:ListItem>小学</asp:ListItem>
            </asp:DropDownList>
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            专业：
        </div>
        <div class="control_item_right">
            <asp:TextBox ID="TextBox3" runat="server" MaxLength="20"></asp:TextBox>
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            毕业院校：
        </div>
        <div class="control_item_right">
            <asp:TextBox ID="TextBox4" runat="server" MaxLength="20"></asp:TextBox>
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            现居住地：
        </div>
        <div class="control_item_right">
            <asp:TextBox ID="TextBox5" runat="server" MaxLength="50"></asp:TextBox>
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            QQ：
        </div>
        <div class="control_item_right">
            <asp:TextBox ID="TextBox7" runat="server" MaxLength="20"></asp:TextBox>
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            Email：
        </div>
        <div class="control_item_right">
            <asp:TextBox ID="TextBox8" runat="server" MaxLength="20"></asp:TextBox>
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            工作经验：
        </div>
        <div class="control_item_right">
            <asp:TextBox ID="TextBox10" runat="server" Height="115px" MaxLength="150" TextMode="MultiLine"
                Width="602px"></asp:TextBox><br />
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            职业技能：
        </div>
        <div class="control_item_right">
            <asp:TextBox ID="TextBox11" runat="server" Height="115px" MaxLength="150" TextMode="MultiLine"
                Width="602px"></asp:TextBox><br />
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            其他：
        </div>
        <div class="control_item_right">
            <asp:TextBox ID="TextBox12" runat="server" Height="115px" MaxLength="150" TextMode="MultiLine"
                Width="602px"></asp:TextBox><br />
        </div>
    </div>
    <div class="control_item">
        <div class="control_item_left">
            &nbsp;
        </div>
        <div class="control_item_right">
            <asp:Button ID="Button1" runat="server" Height="35px" OnClick="Button1_Click" Text="提交"
                Width="108px" />
        </div>
    </div>
</div>

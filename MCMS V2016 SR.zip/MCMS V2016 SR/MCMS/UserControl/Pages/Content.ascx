﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Content.ascx.cs" Inherits="MCMS.UserControl.Pages.Content" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_right">
    <asp:Label ID="Label1" runat="server" Text="[显示联系信息]"></asp:Label>
</div>

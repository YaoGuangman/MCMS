﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.UserControl
{
    public partial class Job_Add : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 提交应聘记录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click(object sender, EventArgs e)
        {
            //获取职位编号
            string jobId = Request.QueryString["id"].ToString();

            //添加记录
            if (Session["UserName"] != null && Session["UserPwd"] != null)
            {
                //性别选择
                string Sex = "男";
                if (RadioButton1.Checked)
                {
                    Sex = "男";
                }
                else
                {
                    Sex = "女";
                }

                //插入
                string SQL = "INSERT INTO Job_Received(姓名, 性别, 年龄, 学历, 专业, 毕业院校, 居住地, 电话, QQ, Email, 工作经验, 职业技能, 其他, 求职日期, Job_ID) VALUES   ('" +
                    TextBox1.Text.Trim() + "', '" +
                    Sex + "', " +
                    TextBox2.Text.Trim() + ", '" +
                    DropDownList1.Text + "', '" +
                    TextBox3.Text.Trim() + "', '" +
                    TextBox4.Text.Trim() + "', '" +
                    TextBox5.Text.Trim() + "', '" +
                    TextBox6.Text.Trim() + "', '" +
                    TextBox7.Text.Trim() + "', '" +
                    TextBox8.Text.Trim() + "', '" +
                    TextBox10.Text + "', '" +
                    TextBox11.Text + "', '" +
                    TextBox12.Text + "', '" +
                    DateTime.Now.ToString() + "', " +
                    jobId + ")";

                CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
                cd.RunSqlCmd(SQL);

                //跳转到指定页面
                Session["GotoURL"] = "~/Job.aspx";
                Session["Info"] = "投递简历成功，请等待我们的电话";
                Response.Redirect("~/MessageBox.aspx");
            }
            else
            {
                //跳转到指定页面
                Session["GotoURL"] = "~/Register/Login.aspx";
                Session["Info"] = "对不起，您目前为游客，请返回登录";
                Response.Redirect("~/Register/MessageBox.aspx");
            }
        }
    }
}
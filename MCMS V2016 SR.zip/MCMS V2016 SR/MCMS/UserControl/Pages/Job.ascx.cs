﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.UserControl
{
    public partial class Job : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 字符串截取方法
        /// </summary>
        /// <param name="subInput"></param>
        /// <param name="subLength"></param>
        /// <returns></returns>
        public string Intercept(string htmlText, int subLength)
        {
            return OperateHtml.InterceptHtmlText(htmlText, subLength);
        } 
    }
}
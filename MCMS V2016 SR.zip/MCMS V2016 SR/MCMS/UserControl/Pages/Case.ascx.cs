﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.UserControl
{
    public partial class Case : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 搜索案例
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click(object sender, EventArgs e)
        {
            string SQL = "SELECT * FROM [Case_Type_View] WHERE (标题 LIKE '%" + TextBox1.Text.Trim() + "%')";
            AccessDataSource1.SelectCommand = SQL;
            GridView1.DataBind();
        }

        /// <summary>
        /// 字符串截取方法
        /// </summary>
        /// <param name="subInput"></param>
        /// <param name="subLength"></param>
        /// <returns></returns>
        public string Intercept(string htmlText, int subLength)
        {
            return OperateHtml.InterceptHtmlText(htmlText, subLength);
        } 
    }
}
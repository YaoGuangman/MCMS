﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="NoteBook.ascx.cs" Inherits="MCMS.UserControl.NoteBook" %>
<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_right">
    <asp:GridView ID="GridView1" runat="server" AllowPaging="True" AutoGenerateColumns="False"
        DataSourceID="AccessDataSource1" EnableModelValidation="True" GridLines="None"
        ShowHeader="False" Style="text-align: left" Width="100%" CellSpacing="4" 
        PageSize="8">
        <Columns>
            <asp:TemplateField>
                <ItemTemplate>
                    <div class="control_item" style="background-color: #DDDDFF">
                        <%#Eval("NoteBook_ID") %>楼:<%#Eval("标题") %></div>
                    <div class="control_item">
                        <%#Eval("正文") %>
                    </div>
                    <div class="control_item" style="text-align: right;">
                        <%#Eval ("昵称") %>在<%#Eval("发布日期") %>时发表 &nbsp; <a href="#Reply"><b>[回复]</b></a>
                    </div>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <PagerSettings FirstPageText="首页" LastPageText="尾页" Mode="NextPreviousFirstLast"
            NextPageText="下一页" PreviousPageText="上一页" />
        <PagerStyle BackColor="#DDDDFF" Font-Bold="True" Height="45px" />
    </asp:GridView>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [NoteBook] ORDER BY [NoteBook_ID] DESC"></asp:AccessDataSource>
    <div class="control_item">
        <a name="Reply">标题：</a><asp:TextBox ID="TextBox1" runat="server" Width="329px" MaxLength="20"
            Style="color: Gray"></asp:TextBox>
        &nbsp;*<asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="TextBox1"
            ErrorMessage="标题不能为空"></asp:RequiredFieldValidator>
    </div>
    <div class="control_item">
        <asp:TextBox ID="TextBox2" runat="server" Height="121px" MaxLength="300" TextMode="MultiLine"
            Width="719px"></asp:TextBox>
    </div>
    <div class="control_item">
        <asp:Button ID="Button1" runat="server" Height="31px" Text="提交" Width="90px" OnClick="Button1_Click" />
    </div>
</div>

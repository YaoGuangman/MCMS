﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="News_Body.ascx.cs" Inherits="MCMS.UserControl.News_Body" %>
<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_right">
    <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" DataKeyNames="News_ID"
        DataSourceID="AccessDataSource1" EnableModelValidation="True" GridLines="None"
        ShowHeader="False" Width="100%" AllowPaging="True" PageSize="1">
        <Columns>
            <asp:TemplateField>
                <ItemTemplate>
                    <div class="control_newsbody_title">
                        <%#Eval("标题") %>
                    </div>
                    <div class="control_newsbody_title2" style="color: #808080">
                        作者：<%#Eval ("撰稿") %>&nbsp;&nbsp;日期：<%#Eval ("发布日期") %></div>
                    <div class="control_newsbody_body">
                        &nbsp;
                    </div>
                    <div class="control_newsbody_body">
                        <%#Eval("正文") %>
                    </div>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <PagerSettings Visible="False" />
    </asp:GridView>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [News] WHERE ([News_ID] = ?) ORDER BY [News_ID] DESC">
        <SelectParameters>
            <asp:QueryStringParameter Name="News_ID" QueryStringField="id" Type="Int32" />
        </SelectParameters>
    </asp:AccessDataSource>
</div>

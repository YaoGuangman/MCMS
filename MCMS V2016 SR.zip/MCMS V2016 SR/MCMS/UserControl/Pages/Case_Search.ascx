﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Case_Search.ascx.cs" Inherits="MCMS.UserControl.Pages.Case_Search" %>

<link href="/Style/UserControl.css" rel="stylesheet" type="text/css" />
<div class="control_body_bottom">
    <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" DataKeyNames="Case_ID"
        DataSourceID="AccessDataSource1" EnableModelValidation="True" AllowPaging="True"
        GridLines="None" ShowHeader="False" Width="100%">
        <Columns>
            <asp:TemplateField>
                <ItemTemplate>
                    <div class="control_case_left">
                        <a href='/Case_Body.aspx?id=<%#Eval("Case_ID") %>'>
                            <img alt="<%#Eval ("标题") %>" src="/Picture/CasePic/<%#Eval("图片地址") %>" style="border-style: none; border-color: inherit; border-width: 0px; margin: 10px; height: 140px; width: 180px;" />
                        </a>
                    </div>
                    <div class="control_case_right" style="margin-top: 10px;">
                        <div class="control_item">
                            <b><a href="/Case_Body.aspx?id=<%#Eval("Case_ID") %>"><%#Eval ("标题") %></a></b>
                        </div>
                        <div class="control_item">
                            编号：<%#Eval ("Case_ID") %>
                        </div>
                        <div class="control_item">
                            分类：<%#Eval ("所属项目") %>
                        </div>
                        <div class="control_item">
                            备注：<%#Intercept(Eval("备注").ToString(),60)%>&nbsp;&nbsp;
                            <a href="/Case_Body.aspx?id=<%#Eval("Case_ID") %>">&gt;&gt;详情</a>
                        </div>
                    </div>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <PagerSettings FirstPageText="首页" LastPageText="尾页" Mode="NextPreviousFirstLast"
            NextPageText="下一页" PreviousPageText="上一页" />
        <PagerStyle BackColor="#DDDDFF" Font-Bold="True" Height="45px" />
    </asp:GridView>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [Case_Type_View] WHERE ([Type_ID] = ?) ORDER BY [Case_ID] DESC">
        <SelectParameters>
            <asp:QueryStringParameter Name="Type_ID" QueryStringField="id" Type="Int32" />
        </SelectParameters>
    </asp:AccessDataSource>
</div>

﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.UserControl
{
    public partial class News : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 字符截取方法
        /// </summary>
        /// <param name="sInput"></param>
        /// <returns></returns>
        public string Intercept(string sInput)
        {
            if (trimLenth != 0)
            {
                if (sInput != null && sInput != string.Empty)
                {
                    if (sInput.Length > TrimLenth)
                        return sInput = sInput.Substring(0, TrimLenth) + "";
                    else
                        return sInput;
                }
                return "";
            }
            return sInput;
        }

        private int trimLenth = 0;//截取长度

        /// <summary>
        /// 设置截取的尺寸
        /// </summary>
        public int TrimLenth
        {
            get { return trimLenth; }
            set { trimLenth = value; }
        }

        /// <summary>
        /// 设置是否显示分页
        /// </summary>
        public bool PagerVisible
        {
            get { return GridView1.PagerSettings.Visible; }
            set { GridView1.PagerSettings.Visible =value ; }
        }

        /// <summary>
        /// 显示条目数
        /// </summary>
        public int PagerCount
        {
            get { return GridView1.PageSize; }
            set { GridView1.PageSize = value; }
        }
    }
}
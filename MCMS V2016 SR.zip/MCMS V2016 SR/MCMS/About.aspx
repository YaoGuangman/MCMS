﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Page.master" AutoEventWireup="true"
    CodeBehind="About.aspx.cs" Inherits="MCMS.WebForm10" %>

<%@ Register Src="UserControl/Pages/About.ascx" TagName="About" TagPrefix="uc1" %>
<asp:Content ID="Content2" ContentPlaceHolderID="WebSiteHead" runat="server">
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="content_title">
        <strong>公司简介</strong>
    </div>
    <div class="content_body">
        <uc1:About ID="About1" runat="server" />
    </div>
</asp:Content>

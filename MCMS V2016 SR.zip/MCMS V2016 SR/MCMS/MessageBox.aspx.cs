﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS
{
    public partial class WebForm12 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //定时跳转到指定页面
            string info = Session["Info"].ToString();
            Label2.Text = info;
        }

        /// <summary>
        /// 跳转到页面
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click(object sender, EventArgs e)
        {
            string goUrl = Session["GotoURL"].ToString();
            Response.Redirect(goUrl);
        }
    }
}
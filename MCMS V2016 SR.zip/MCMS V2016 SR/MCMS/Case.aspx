﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Page.master" AutoEventWireup="true"
    CodeBehind="Case.aspx.cs" Inherits="MCMS.WebForm4" %>

<%@ Register Src="/UserControl/Pages/Case.ascx" TagName="Case" TagPrefix="uc1" %>
<asp:Content ID="Content2" ContentPlaceHolderID="WebSiteHead" runat="server">
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="content_title">
        <strong>产品展示</strong>
    </div>
    <div class="content_body">
        <uc1:Case ID="Case1" runat="server" />
    </div>
</asp:Content>

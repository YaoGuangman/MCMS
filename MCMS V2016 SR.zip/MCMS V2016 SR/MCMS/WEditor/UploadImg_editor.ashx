﻿<%@ WebHandler Language="C#" CodeBehind="UploadImg_editor.ashx.cs" Class="MCMS.UploadImg_editor1" %>

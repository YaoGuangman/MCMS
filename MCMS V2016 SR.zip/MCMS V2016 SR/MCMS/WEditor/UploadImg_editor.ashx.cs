﻿using System;
using System.Collections.Generic;
using System.Web;
using System.IO;

namespace MCMS
{
    /// <summary>
    /// UploadImg_editor 的摘要说明
    /// </summary>
    public class UploadImg_editor1 : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            //设置编码方式
            context.Response.ContentType = "text/html";
            context.Response.Charset = "utf-8";

            //返回上传结果页面
            string iframeTemplate = "<iframe src='/WEditor/UploadImg_assist.html#{0}'></iframe>"; //【注意】设置 <iframe src="返回结果页面 /UploadImg_assist.html 的位置"></iframe>
            string result;  //将会存储返回结果

            //上传图片文件
            HttpPostedFile file = context.Request.Files["wangEditor_uploadImg"];
            if (file == null)
            {
                //返回结果
                // iframeTemplate 中的“{0}”被替换为“上传失败，未获取到文件”，代表上传失败
                // result 被赋值为：<iframe src="http://UploadImg_assist.html#上传失败，未获取到文件"></iframe>
                result = string.Format(iframeTemplate, "上传失败，未获取到文件");
            }
            else
            {
                //验证
                string contentType = file.ContentType.ToLower();
                string ext = Path.GetExtension(file.FileName).ToLower();

                if (CanUpload(ext))
                {
                    //上传图片文件到指定目录
                    string path = context.Server.MapPath("~/Picture/NewsPic/"); //【注意】网站中有一个 /NewsPic 文件夹，用于保存上传的图片
                    string fileName = DateTime.Now.ToString("yyyyMMddHHmmssfff") + (new Random()).Next(100, 999) + ext;
                    string imageUrl = path + fileName;
                    file.SaveAs(imageUrl);

                    //返回结果
                    // iframeTemplate 中的“{0}”被替换为“ok|图片的url地址”，代表上传成功
                    // result 被赋值为：<iframe src="http://UploadImg_assist.html#ok|图片的url地址"></iframe>
                    string url = "/Picture/NewsPic/" + fileName;//【注意】获取上传后图片的 URL 地址
                    result = string.Format(iframeTemplate, "ok|" + url);
                }
                else
                {
                    result = string.Format(iframeTemplate, contentType + "文件类型仅支持jpg,jpeg,png,gif");
                }
            }

            context.Response.Write(result);
            context.Response.End();
        }

        private bool CanUpload(string ext)
        {
            //TODO:是否合法的扩展名
            //允许上传的图片格式为jpg/jpeg、png和gif类型
            if (ext.ToLower() == ".jpg" || ext.ToLower() == ".jpeg" || ext.ToLower() == ".png"
                || ext.ToLower() == ".gif")
            {
                return true;
            }
            return false;
        }

        private bool FileTypeAllowed(HttpPostedFile hpf)
        {
            string fileType = hpf.ContentType.ToLower();
            //是否合法的文件类型，通过FileUpload的ContentType属性来确定类型
            if (fileType == "image/jpg" || fileType == "image/jpeg" || fileType == "image/x-png" || fileType == "image/gif") return true;
            return false;

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.WEditor
{
    public partial class WEditor : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 获取或设置输入框文字值
        /// </summary>
        public string Value
        {
            get { return TextBox1.Text; }
            set { TextBox1.Text = value; }
        }

        /// <summary>
        /// 获取设置控件宽度
        /// </summary>
        public int Width
        {
            get { return int.Parse(TextBox1.Width.ToString()); }
            set { TextBox1.Width = value; }
        }

        /// <summary>
        /// 获取设置控件高度
        /// </summary>
        public int Height
        {
            get { return int.Parse(TextBox1.Height.ToString()); }
            set { TextBox1.Height = value; }
        }
    }
}
﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="WEditor.ascx.cs" Inherits="MCMS.WEditor.WEditor" %>

<!--引入wangEditor.css-->
<link rel="stylesheet" type="text/css" href="/WEditor/css/wangEditor-1.3.13.2.css" />
<script type="text/javascript" src="/WEditor/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="/WEditor/js/wangEditor-1.3.13.2.js"></script>
<script type="text/javascript">
    $(function () {
        var editor = $("#<%=TextBox1.ClientID %>").wangEditor({
            "uploadUrl": "/WEditor/UploadImg_editor.ashx"
        });
    });
</script>

<asp:TextBox ID="TextBox1" runat="server" Height="500px" TextMode="MultiLine" Width="100%" BorderStyle="None"></asp:TextBox>

<!--【注意】在此需要配置跨域上传返回页地址-->
<!--"uploadUrl": "/WEditor/UploadImg_editor.ashx"-->

<!--所有可选菜单配置-->
<!--
    [
    ['viewSourceCode'],
    ['bold', 'underline', 'italic', 'foreColor', 'backgroundColor', 'strikethrough'],
    ['blockquote', 'fontFamily', 'fontSize', 'setHead', 'list', 'justify'],
    ['createLink', 'unLink', 'insertTable', 'insertExpression'],
    ['insertImage', 'insertVideo', 'insertLocation','insertCode'],
    ['undo', 'redo', 'fullScreen']
    ]   
-->
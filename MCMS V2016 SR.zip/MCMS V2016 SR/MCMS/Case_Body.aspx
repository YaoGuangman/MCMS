﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Page.master" AutoEventWireup="true"
    CodeBehind="Case_Body.aspx.cs" Inherits="MCMS.WebForm5" %>

<%@ Register Src="UserControl/Pages/Case_Body.ascx" TagName="Case_Body" TagPrefix="uc1" %>
<asp:Content ID="Content2" ContentPlaceHolderID="WebSiteHead" runat="server">
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="content_title">
        <strong>产品详情</strong>
    </div>
    <div class="content_body">
        <uc1:Case_Body ID="Case_Body1" runat="server" />
    </div>
</asp:Content>

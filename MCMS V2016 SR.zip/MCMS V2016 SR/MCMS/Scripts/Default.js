﻿$(function () {
        //截取标签内字符串长度公用方法   
        jQuery.each(jQuery("[split]"), function (i) {
        //获得截取长度   
        var toLength = parseInt($(this).attr("split"));
        if (jQuery.trim(this.innerHTML).length > toLength) {
            this.title = this.innerHTML;
            this.innerHTML = jQuery.trim(this.innerHTML).substring(0, toLength) + "";
        }
    });
});

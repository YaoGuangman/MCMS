﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS
{
    public partial class WebSite : System.Web.UI.MasterPage
    {
        protected void Page_Init(object sender, EventArgs e)
        {
            //动态更改网站内页横幅图片
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
            string SQL = "SELECT 内页图片 FROM [Style]";
            string img = cd.GetFirstValue(SQL).ToString();//获取图片
            MyImage.ImageUrl = "~/Picture/PagePic/" + img;
        }
    }
}
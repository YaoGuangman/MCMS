﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Page.master" AutoEventWireup="true"
    CodeBehind="Case_Search.aspx.cs" Inherits="MCMS.WebForm13" %>

<%@ Register Src="UserControl/Pages/Case_Search.ascx" TagName="Case_Search" TagPrefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="WebSiteHead" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="content_title">
        <strong>分类展示</strong>
    </div>
    <div class="content_body">
        <uc1:Case_Search ID="Case_Search1" runat="server" />
    </div>
</asp:Content>

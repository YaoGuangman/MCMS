﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Page.master" AutoEventWireup="true"
    CodeBehind="Job_Body.aspx.cs" Inherits="MCMS.WebForm8" %>

<%@ Register Src="UserControl/Pages/Job_Body.ascx" TagName="Job_Body" TagPrefix="uc1" %>
<asp:Content ID="Content2" ContentPlaceHolderID="WebSiteHead" runat="server">
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="content_title">
        <strong>职位详情</strong>
    </div>
    <div class="content_body">
        <uc1:Job_Body ID="Job_Body1" runat="server" />
    </div>
</asp:Content>

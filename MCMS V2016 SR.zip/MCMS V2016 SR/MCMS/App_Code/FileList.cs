﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Collections;
using System.IO;

namespace MCMS
{
    public class FileList
    {
        //字段声明
        private ArrayList myfilelistpath = new ArrayList();//文件路径
        private ArrayList myfilelistname = new ArrayList();//文件名称

        //属性声明

        public ArrayList GetFileListPath
        {
            get { return myfilelistpath; }
        }

        public ArrayList GetFileListName
        {
            get { return myfilelistname; }
        }

        /// <summary>
        /// 构造函数并遍历文件夹获取文件名称，路径
        /// </summary>
        /// <param name="sourceDirectory"></param>
        public FileList(string sourceDirectory)
        {
            DirectoryInfo diSource = new DirectoryInfo(sourceDirectory);
            ListAll(diSource);
        }
        public void ListAll(DirectoryInfo source)
        {
            foreach (FileInfo fi in source.GetFiles())
            {
                myfilelistpath.Add(fi.FullName);
                myfilelistname.Add(fi.Name);
            }
            foreach (DirectoryInfo diSourceSubDir in source.GetDirectories())
            {
                ListAll(diSourceSubDir);
            }
        }

        /// <summary>
        /// 删除指定文件夹，文件
        /// </summary>
        /// <param name="dir"></param>
        public static void DeleteFolder(string dir)
        {
            foreach (string d in Directory.GetFileSystemEntries(dir))
            {
                if (File.Exists(d))
                {
                    FileInfo fi = new FileInfo(d);
                    if (fi.Attributes.ToString().IndexOf("ReadOnly") != -1)
                        fi.Attributes = FileAttributes.Normal;
                    File.Delete(d);//直接删除其中的文件   
                }
                else
                    DeleteFolder(d);//递归删除子文件夹   
            }
            Directory.Delete(dir);//删除已空文件夹   
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Text;//
using System.IO;//
using System.Security.Cryptography;//

namespace MCMS
{
        /// <summary>
        /// 字符串加密类
        /// </summary>
        public class EncryptStringClass
        {
            //默认密钥向量（等于八位）
            private static byte[] IV = { 0x34,0x90, 0xCD,  0x56, 0x78,0x12,  0xAB, 0xEF };

            /// <summary>
            /// 截取密码为8位字符
            /// </summary>
            /// <param name="key"></param>
            /// <returns></returns>
            public static string SubKey(string key)
            {
                if (key.Length >= 8)
                {
                    key = key.Substring(0, 8);
                }
                else
                {
                    key = key + "00000000";
                    key = key.Substring(0, 8);
                }
                return key;
            }

            /// <summary>
            /// DES加密字符串
            /// </summary>
            /// <param name="encryptString">待加密的字符串</param>
            /// <param name="passWord">加密密钥,要求为8位</param>
            /// <returns>加密成功返回加密后的字符串，失败返回源串</returns>
            public static string EncryptString(string encryptString, string passWord)
            {
                try
                {
                    passWord = SubKey(passWord);//截取为8位
                    byte[] rgbKey = Encoding.UTF8.GetBytes(passWord);
                    byte[] inputByteArray = Encoding.UTF8.GetBytes(encryptString);
                    DESCryptoServiceProvider dCSP = new DESCryptoServiceProvider();

                    MemoryStream mStream = new MemoryStream();
                    using (CryptoStream cStream = new CryptoStream(mStream, dCSP.CreateEncryptor(rgbKey, IV), CryptoStreamMode.Write))
                    {
                        cStream.Write(inputByteArray, 0, inputByteArray.Length);
                        cStream.FlushFinalBlock();
                    }
                    return Convert.ToBase64String(mStream.ToArray());
                }
                catch
                {
                    return encryptString;
                }
            }

            /// <summary>
            /// DES解密字符串
            /// </summary>
            /// <param name="decryptString">待解密的字符串</param>
            /// <param name="passWord">解密密钥,要求为8位,和加密密钥相同</param>
            /// <returns>解密成功返回解密后的字符串，失败返源串</returns>
            public static string DecryptString(string decryptString, string passWord)
            {
                try
                {
                    passWord = SubKey(passWord);//截取为8位
                    byte[] rgbKey = Encoding.UTF8.GetBytes(passWord);
                    byte[] inputByteArray = Convert.FromBase64String(decryptString);
                    DESCryptoServiceProvider DCSP = new DESCryptoServiceProvider();

                    MemoryStream mStream = new MemoryStream();
                    using (CryptoStream cStream = new CryptoStream(mStream, DCSP.CreateDecryptor(rgbKey, IV), CryptoStreamMode.Write))
                    {
                        cStream.Write(inputByteArray, 0, inputByteArray.Length);
                        cStream.FlushFinalBlock();
                    }
                    return Encoding.UTF8.GetString(mStream.ToArray());
                }
                catch
                {
                    return decryptString;
                }
            }
        }
    }
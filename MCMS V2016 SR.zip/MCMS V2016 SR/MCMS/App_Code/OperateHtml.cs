﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Text.RegularExpressions;//

namespace MCMS
{
    public class OperateHtml
    {
        /// <summary>
        /// 获取html中的图片地址
        /// </summary>
        /// <param name="htmlText">需要获取图片的html内容</param>
        /// <returns>获取到的图片地址数组</returns>
        public static string[] GetHtmlImageUrlList(string htmlText)
        {
            // 定义正则表达式用来匹配 img 标签  
            Regex regImg = new Regex(@"<img\b[^<>]*?\bsrc[\s\t\r\n]*=[\s\t\r\n]*[""']?[\s\t\r\n]*(?<imgUrl>[^\s\t\r\n""'<>]*)[^<>]*?/?[\s\t\r\n]*>", RegexOptions.IgnoreCase);

            // 搜索匹配的字符串  
            MatchCollection matches = regImg.Matches(htmlText);
            int i = 0;
            string[] imgUrlList = new string[matches.Count];

            // 取得匹配项列表  
            foreach (Match match in matches)
            {
                imgUrlList[i++] = match.Groups["imgUrl"].Value;
            }

            return imgUrlList;
        }

        /// <summary>
        /// 替换html中的字符
        /// </summary>
        /// <param name="htmlText">需要替换内容的html内容</param>
        /// <param name="sourceText">需要替换的字符</param>
        /// <param name="replaceText">替换为的字符</param>
        /// <returns>替换掉字符的html内容</returns>
        public static string ReplaceHtmlText(string htmlText, string sourceText, string replaceText)
        {
            if (htmlText.IndexOf(sourceText) != -1)
            {
                //判断字符串是否含有某个字符串  ,并替换
                htmlText = htmlText.Replace(sourceText, replaceText);
            }
            return htmlText;
        }

        /// <summary>
        /// html字符截取方法
        /// </summary>
        /// <param name="htmlText">待截取的html内容</param>
        /// <param name="htmlText">截取长度</param>
        /// <returns>截取到的html内容</returns>
        public static string InterceptHtmlText(string htmlText, int subLength)
        {
            htmlText = ClearHtmlTag(htmlText);//去除标签
            if (htmlText != null && htmlText != string.Empty)
            {
                if (htmlText.Length > subLength)
                    return htmlText = htmlText.Substring(0, subLength) + "";
                else
                    return htmlText;
            }
            return "";
        }

        /// <summary>
        /// 将html标签转化为空格
        /// </summary>
        /// <param name="htmlText">待转化的html内容</param>
        /// <returns>经过转化的字符串</returns>
        public static string ClearHtmlTag(string htmlText)
        {
            Regex objRegExp = new Regex("<(.|\n)+?>");
            string strOutput = objRegExp.Replace(htmlText, "");
            strOutput = strOutput.Replace("&nbsp;", "");
            return strOutput;
        }

        /// <summary>
        /// 删除html存放在服务器的图片
        /// </summary>
        /// <param name="htmlText">需要操作的html文件内容</param>
        public static void DeleteHtmlImages(string htmlText)
        {
            try
            {
                //分析html中所有图片链接
                string[] imgList = OperateHtml.GetHtmlImageUrlList(htmlText);
                foreach (string img in imgList)
                {
                    try
                    {
                        //判断字符串如果不存在“http://”和“/exp/”则说明不是网络图片和表情图标，则删除该本地图片
                        if (img.IndexOf("http://") < 0 && img.IndexOf("/exp/") < 0)
                        {
                            System.IO.File.Delete(@System.Web.HttpContext.Current.Server.MapPath(img));
                        }
                    }
                    catch
                    {
                        continue;
                    }
                }
            }
            catch
            { }
        }
    }
}
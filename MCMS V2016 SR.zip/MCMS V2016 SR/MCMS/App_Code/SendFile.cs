﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI.WebControls;//
using System.IO;//

namespace MCMS
{
    public class SendFile
    {
        /// <summary>
        /// 文件上传方法
        /// </summary>
        /// <param name="allowFileExtension">允许上传的类型，中间用","隔开</param>
        /// <param name="allowFileLength">允许上传的最大字节数</param>
        /// <param name="fileUploadPath">上传到的目录</param>
        /// <param name="file">使用的FileUpload上传控件</param>
        /// <returns>返回文件名称</returns>
        public static string SendFileUpload(string allowFileExtension, int allowFileLength, string fileUploadPath, FileUpload file)
        {
            if (file.HasFile)//判断FileUpload是否有需要上传的文件
            {
                //文件信息
                string fileName = file.FileName;//文件名
                string fileExt = System.IO.Path.GetExtension(fileName);//文件类型
                int fileLength = (int)file.FileContent.Length;//文件大小

                //修改上传后的文件名
                string newFileName = DateTime.Now.ToString("yyyyMMddHHmmssfff") + (new Random()).Next(100, 999) + fileExt;

                //验证并上传
                if (allowFileExtension.LastIndexOf(fileExt) > -1 && fileLength < allowFileLength)//判断文件类型和大小
                {
                    file.PostedFile.SaveAs(fileUploadPath + newFileName);//上传文件
                    return newFileName;//返回文件名
                }
                else
                {
                    return null;
                }

            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 发送邮件
        /// </summary>
        /// <param name="toEmail">接收信箱</param>
        /// <param name="subject">主题</param>
        /// <param name="body">正文</param>
        public static void SendEmail(string toEmail, string subject, string body)
        {
            System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();

            //这里使用QQ的邮箱来发送测试，如果是其它邮箱，请根据其它邮箱POP3/IMAP/SMTP服务来设置  
            client.Host = "smtp.qq.com"; client.UseDefaultCredentials = false;
            client.Credentials = new System.Net.NetworkCredential("lingyun.yao@qq.com", "yao@870309");
            client.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
            System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage("lingyun.yao@qq.com", toEmail);
            message.Subject = subject;
            message.Body = body;
            message.BodyEncoding = System.Text.Encoding.UTF8;
            message.IsBodyHtml = true;

            try
            {
                client.Send(message);
            }
            catch
            {
            }
        }
    }
}
﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Page.master" AutoEventWireup="true"
    CodeBehind="News_Body.aspx.cs" Inherits="MCMS.WebForm3" %>

<%@ Register Src="UserControl/Pages/News_Body.ascx" TagName="News_Body" TagPrefix="uc1" %>
<asp:Content ID="Content2" ContentPlaceHolderID="WebSiteHead" runat="server">
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="content_title">
        <strong>新闻正文</strong>
    </div>
    <div class="content_body">
        <uc1:News_Body ID="News_Body1" runat="server" />
    </div>
</asp:Content>

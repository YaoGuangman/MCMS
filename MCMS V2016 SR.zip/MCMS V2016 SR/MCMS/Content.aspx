﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Page.master" AutoEventWireup="true"
    CodeBehind="Content.aspx.cs" Inherits="MCMS.WebForm6" %>

<%@ Register Src="UserControl/Pages/Content.ascx" TagName="Content" TagPrefix="uc1" %>
<asp:Content ID="Content3" ContentPlaceHolderID="WebSiteHead" runat="server">
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="content_title">
        <strong>联系我们</strong>
    </div>
    <div class="content_body" style="min-height: 600px;">
        <uc1:Content ID="Content4" runat="server" />
    </div>
</asp:Content>

﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin/Admin.master" AutoEventWireup="true"
    CodeBehind="News_Edit.aspx.cs" Inherits="MCMS.Admin.WebForm6" %>

<asp:Content ID="Content1" ContentPlaceHolderID="Contenthead" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <table>
        <tr>
            <td class="content_admin_left">
                <asp:Button ID="Button4" runat="server" PostBackUrl="~/Admin/News_Add.aspx" Text="添加新闻"
                    Width="96px" /><br />
                <asp:Button ID="Button5" runat="server" PostBackUrl="~/Admin/News_Edit.aspx" Text="管理新闻"
                    Width="96px" /><br />
            </td>
            <td class="content_admin_right">
                <asp:GridView ID="GridView1" runat="server" AllowPaging="True" AutoGenerateColumns="False"
                    BackColor="White" BorderColor="#CCCCCC" BorderStyle="None" BorderWidth="1px"
                    CellPadding="4" DataKeyNames="News_ID" DataSourceID="AccessDataSource1" EnableModelValidation="True"
                    ForeColor="Black" GridLines="Horizontal" PageSize="20" Width="100%" OnRowDeleted="GridView1_RowDeleted"
                    OnRowUpdated="GridView1_RowUpdated">
                    <Columns>
                        <asp:TemplateField HeaderText="操作">
                            <ItemTemplate>
                                <a href="News_Add.aspx?id=<%#Eval("News_ID") %>">编辑</a>
                                <a href="News_Delete.aspx?id=<%#Eval("News_ID") %>">删除</a>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="标题">
                            <ItemTemplate>
                                <a href="../News_Body.aspx?id=<%#Eval("News_ID") %>">
                                    <%#Eval("标题") %></a>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <RowStyle Height="40px" />
                    <HeaderStyle BackColor="#333333" Font-Bold="True" ForeColor="White" Height="40px" HorizontalAlign="Left" />
                    <PagerStyle BackColor="#E6E6E6" ForeColor="Black" HorizontalAlign="Right" Font-Bold="True" Font-Size="Large" Height="40px" />
                </asp:GridView>
                <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
                    SelectCommand="SELECT * FROM [News] ORDER BY [News_ID] DESC" DeleteCommand="DELETE FROM News WHERE (News_ID = ?)"></asp:AccessDataSource>
            </td>
        </tr>
    </table>
</asp:Content>

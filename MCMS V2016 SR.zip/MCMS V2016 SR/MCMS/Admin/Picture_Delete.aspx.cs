﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Register
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 删除文件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click(object sender, EventArgs e)
        {
            //删除
            try
            {
                string deleteFile = Request.QueryString["file"].ToString();
                System.IO.File.Delete(@Server.MapPath(deleteFile.Substring(1)));
            }
            catch
            { }

            //提示
            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/Picture_Edit.aspx";
            Session["Info"] = "删除文件成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }
    }
}
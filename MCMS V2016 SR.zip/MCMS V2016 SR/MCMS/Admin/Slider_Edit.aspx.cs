﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Admin
{
    public partial class WebForm16 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 添加横幅图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            //上次照片
            string sendPath = @Server.MapPath("/Picture/Slider/");
            string picPath = SendFile.SendFileUpload(".jpg,.png,.gif", 1000000, sendPath, FileUpload1);

            //添加数据
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
            string SQL = "INSERT INTO Slider (链接地址,图片地址) VALUES   ('" +
                    TextBox1.Text.Trim() + "', '" +
                    picPath + "')";
            cd.RunSqlCmd(SQL);

            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/Slider_Edit.aspx";
            Session["Info"] = "添加横幅成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }

        protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/Slider_Edit.aspx";
            Session["Info"] = "删除横幅成功，请手动删除图片文件";
            Response.Redirect("~/Register/MessageBox.aspx");
        }

        protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/Slider_Edit.aspx";
            Session["Info"] = "更新横幅信息成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }
    }
}
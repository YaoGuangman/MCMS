﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Admin
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //获取原始数据
                if (Request.QueryString["id"] != null)//不存在QueryString
                {
                    //获取原始的数据到输入框中
                    string newsID = Request.QueryString["id"].ToString();
                    CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

                    string SQL = "SELECT 标题 FROM [News] WHERE (News_ID = " + newsID + ")";
                    TextBox1.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 撰稿 FROM [News] WHERE (News_ID = " + newsID + ")";
                    TextBox2.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 正文 FROM [News] WHERE (News_ID = " + newsID + ")";
                    WEditor1.Value = cd.GetFirstValue(SQL).ToString();
                }
            }
        }

        /// <summary>
        /// 添加新闻
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            //添加或更新新闻
            if (Request.QueryString["id"] != null)//存在QueryString
            {
                //更新
                string newsID = Request.QueryString["id"].ToString();
                string SQL = "UPDATE  News SET  标题 = '" +
                    TextBox1.Text + "', 撰稿 = '" +
                    TextBox2.Text + "', 正文 = '" +
                    WEditor1.Value + "', 发布日期 = '" +
                    DateTime.Now.ToString() + "' WHERE   (News.News_ID = " +
                    newsID + ")";
                CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
                cd.RunSqlCmd(SQL);

                //跳转到指定页面
                Session["GotoURL"] = "~/Admin/News_Edit.aspx";
                Session["Info"] = "新闻更新成功";
                Response.Redirect("~/Register/MessageBox.aspx");

            }
            else//不存在QueryString
            {
                //编辑
                string SQL = "INSERT INTO News (标题, 撰稿, 正文,发布日期) VALUES   ('" +
                    TextBox1.Text.Trim() + "', '" +
                    TextBox2.Text.Trim() + "', '" +
                    WEditor1.Value + "', '" +
                    DateTime.Now.ToString() + "')";

                CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
                cd.RunSqlCmd(SQL);

                //跳转到指定页面
                Session["GotoURL"] = "~/Admin/News_Edit.aspx";
                Session["Info"] = "添加新闻成功";
                Response.Redirect("~/Register/MessageBox.aspx");
            }
        }
    }
}
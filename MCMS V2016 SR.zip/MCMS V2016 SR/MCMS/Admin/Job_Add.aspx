﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin/Admin.master" AutoEventWireup="true"
    CodeBehind="Job_Add.aspx.cs" Inherits="MCMS.Admin.WebForm11" %>

<%@ Register src="../WEditor/WEditor.ascx" tagname="WEditor" tagprefix="uc1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="Contenthead" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <table>
        <tr>
            <td class="content_admin_left">
                <asp:Button ID="Button4" runat="server" PostBackUrl="~/Admin/Job_Add.aspx" Text="添加职位"
                    Width="96px" /><br />
                <asp:Button ID="Button2" runat="server" PostBackUrl="~/Admin/Job_Edit.aspx" Text="管理职位"
                    Width="96px" /><br />
                <asp:Button ID="Button5" runat="server" PostBackUrl="~/Admin/Job_Received_Edit.aspx"
                    Text="应聘信息" Width="96px" /><br />
            </td>
            <td class="content_admin_right">
                <div class="admin_item">
                    <div class="admin_item_left">
                        职位名称：
                    </div>
                    <div class="admin_item_right">
                        <asp:TextBox ID="TextBox1" runat="server" MaxLength="50" Width="263px"></asp:TextBox>
                        <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="TextBox1"
                            ErrorMessage="标题不能为空"></asp:RequiredFieldValidator>
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        有效期至：
                    </div>
                    <div class="admin_item_right">
                        <asp:TextBox ID="TextBox2" runat="server"></asp:TextBox>
                        (示例格式：2011-03-12）<asp:RegularExpressionValidator ID="RegularExpressionValidator1"
                            runat="server" ControlToValidate="TextBox2" ErrorMessage="输入的日期格式有误" ValidationExpression="(19|20)\d{2}[/\s\-\.]*(0[1-9]|1[0-2]|[1-9])[/\s\-\.]*(0[1-9]|3[01]|[12][0-9]|[1-9])"></asp:RegularExpressionValidator>
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        职位介绍：
                    </div>
                    <div class="admin_item_right">
                        <uc1:WEditor ID="WEditor1" runat="server" />
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:ImageButton ID="ImageButton1" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                            OnClick="ImageButton1_Click" />
                    </div>
                </div>
            </td>
        </tr>
    </table>
</asp:Content>

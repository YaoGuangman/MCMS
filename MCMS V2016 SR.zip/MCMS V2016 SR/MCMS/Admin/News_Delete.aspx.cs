﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Admin
{
    public partial class WebForm18 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //获取需要删除的新闻ID
            string newsId = Request.QueryString["id"].ToString();

            //删除职位图片文件
            string SQL = @"SELECT 正文 FROM  [News] WHERE (News_ID =" + newsId + ")";
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
            string jobText = cd.GetFirstValue(SQL).ToString();
            OperateHtml.DeleteHtmlImages(jobText);

            //删除职位
            SQL = "DELETE FROM [News] WHERE (News_ID = " + newsId + ")";
            cd.RunSqlCmd(SQL);

            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/News_Edit.aspx";
            Session["Info"] = "已删除新闻中的图片和记录成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }
    }
}
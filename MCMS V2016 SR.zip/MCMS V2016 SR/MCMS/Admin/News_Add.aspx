﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin/Admin.master" AutoEventWireup="true"
    CodeBehind="News_Add.aspx.cs" Inherits="MCMS.Admin.WebForm3" %>

<%@ Register src="../WEditor/WEditor.ascx" tagname="WEditor" tagprefix="uc1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="Contenthead" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <table>
        <tr>
            <td class="content_admin_left">
                <asp:Button ID="Button4" runat="server" PostBackUrl="~/Admin/News_Add.aspx" Text="添加新闻"
                    Width="96px" /><br />
                <asp:Button ID="Button5" runat="server" PostBackUrl="~/Admin/News_Edit.aspx" Text="管理新闻"
                    Width="96px" /><br />
            </td>
            <td class="content_admin_right">
                <div class="admin_item">
                    <div class="admin_item_left">
                        标题：
                    </div>
                    <div class="admin_item_right">
                        <asp:TextBox ID="TextBox1" runat="server" Width="245px" MaxLength="50"></asp:TextBox>
                        <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="TextBox1"
                            ErrorMessage="标题不能为空"></asp:RequiredFieldValidator>
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        撰稿：
                    </div>
                    <div class="admin_item_right">
                        <asp:TextBox ID="TextBox2" runat="server" Width="121px" MaxLength="50"></asp:TextBox>
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        正文：
                    </div>
                    <div class="admin_item_right">
                        <uc1:WEditor ID="WEditor1" runat="server" />
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:ImageButton ID="ImageButton1" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                            OnClick="ImageButton1_Click" />
                    </div>
                </div>
            </td>
        </tr>
    </table>
</asp:Content>

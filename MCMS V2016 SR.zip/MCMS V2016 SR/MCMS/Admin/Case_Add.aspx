﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin/Admin.master" AutoEventWireup="true"
    CodeBehind="Case_Add.aspx.cs" Inherits="MCMS.Admin.WebForm8" %>

<asp:Content ID="Content1" ContentPlaceHolderID="Contenthead" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <table>
        <tr>
            <td class="content_admin_left">
                <asp:Button ID="Button4" runat="server" PostBackUrl="~/Admin/Case_Type.aspx" Text="产品分类"
                    Width="96px" /><br />
                <asp:Button ID="Button2" runat="server" PostBackUrl="~/Admin/Case_Add.aspx" Text="添加产品"
                    Width="96px" /><br />
                <asp:Button ID="Button3" runat="server" PostBackUrl="~/Admin/Case_Edit.aspx" Text="管理产品"
                    Width="96px" /><br />
            </td>
            <td class="content_admin_right">
                <div class="admin_item">
                    <div class="admin_item_left">
                        标题:
                    </div>
                    <div class="admin_item_right">
                        <asp:TextBox ID="TextBox1" runat="server" Width="282px" MaxLength="50"></asp:TextBox>
                        <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ErrorMessage="标题不能为空"
                            ControlToValidate="TextBox1"></asp:RequiredFieldValidator>
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        图片:
                    </div>
                    <div class="admin_item_right">
                        <asp:FileUpload ID="FileUpload1" runat="server" Width="221px" BorderColor="White" BorderStyle="Solid" BorderWidth="3px" Height="24px" />
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        分类:
                    </div>
                    <div class="admin_item_right">
                        <asp:DropDownList ID="DropDownList1" runat="server" Width="146px" DataSourceID="AccessDataSource1"
                            DataTextField="所属项目" DataValueField="所属项目">
                        </asp:DropDownList>
                        <asp:Button ID="Button5" runat="server" PostBackUrl="~/Admin/Case_Type.aspx" Text="管理分类"
                            Width="96px" />
                        <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
                            SelectCommand="SELECT [所属项目] FROM [Case_Type]"></asp:AccessDataSource>
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        备注:
                    </div>
                    <div class="admin_item_right">
                        <asp:TextBox ID="TextBox4" runat="server" Height="430px" TextMode="MultiLine" Width="98%"></asp:TextBox>
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:ImageButton ID="ImageButton1" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                            OnClick="ImageButton1_Click" />
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                    </div>
                    <div class="admin_item_right">
                    </div>
                </div>
            </td>
        </tr>
    </table>
</asp:Content>

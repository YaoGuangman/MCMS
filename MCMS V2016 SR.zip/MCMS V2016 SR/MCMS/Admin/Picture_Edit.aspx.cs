﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;//

namespace MCMS.Admin
{
    public partial class WebForm14 : System.Web.UI.Page
    {
        /// <summary>
        /// 查看~/Picture/Logo文件夹下的图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Panel1.Controls.Clear();
            //获取文件和路径
            string filePath = Server.MapPath("~/Picture/Logo");//目录
            FileList fl = new FileList(filePath);
            ArrayList al = new ArrayList();
            al = fl.GetFileListName;
            foreach (string str in al)
            {
                //图像链接
                string fullPath = "~/Picture/Logo/" + str;
                ImageButton ib = new ImageButton();
                ib.ImageUrl = fullPath;
                ib.AlternateText = "图像：" + str;
                ib.Width = 120;
                //ib.Height = 140;
                ib.PostBackUrl = "Picture_Delete.aspx?file=" + fullPath;
                ib.ToolTip = "图像：" + str;
                ib.BorderWidth = 20;
                ib.BorderColor = System.Drawing.Color.White;
                this.Panel1.Controls.Add(ib);
            }
        }

        /// <summary>
        /// 打开指定文件夹内图片查看
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click(object sender, EventArgs e)
        {
            this.Panel1.Controls.Clear();
            //获取文件和路径
            string filePath = Server.MapPath("~/Picture/" + DropDownList1.Text);//目录
            FileList fl = new FileList(filePath);
            ArrayList al = new ArrayList();
            al = fl.GetFileListName;
            foreach (string str in al)
            {
                //图像链接
                string fullPath = "~/Picture/" + DropDownList1.Text + "/" + str;
                ImageButton ib = new ImageButton();
                ib.ImageUrl = fullPath;
                ib.AlternateText = "图像：" + str;
                ib.Width = 120;
                //ib.Height = 140;
                ib.PostBackUrl = "Picture_Delete.aspx?file=" + fullPath;
                ib.ToolTip = "图像：" + str;
                ib.BorderWidth = 20;
                ib.BorderColor = System.Drawing.Color.White;
                this.Panel1.Controls.Add(ib);
            }
        }
    }
}
﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Style_Edit.ascx.cs"
    Inherits="MCMS.Admin.Style_Edit" %>
<table class="style1">
    <tr>
        <td style="text-align: left; height: 45px;">
            <span style="text-align: left"><strong>内置网站风格模板：</strong></span>
        </td>
        <td style="height: 45px">
            &nbsp;
        </td>
        <td style="height: 45px">
            &nbsp;
        </td>
        <td style="height: 45px">
            &nbsp;
        </td>
    </tr>
    <tr>
        <td style="text-align: center">
            <asp:Image runat="server" Height="176px" Width="177px" ID="Image1" ImageUrl="~/Images/Style/Default.jpg">
            </asp:Image>
        </td>
        <td style="text-align: center">
            <asp:Image runat="server" Height="176px" Width="177px" ID="Image2" ImageUrl="~/Images/Style/Sliver.png">
            </asp:Image>
        </td>
        <td style="text-align: center">
            <asp:Image runat="server" Height="176px" Width="177px" ID="Image3" ImageUrl="~/Images/Style/Green.png">
            </asp:Image>
        </td>
        <td style="font-weight: 700; text-align: center">
            <asp:Image runat="server" Height="176px" Width="177px" ID="Image4" ImageUrl="~/Images/Style/Red.png">
            </asp:Image>
        </td>
    </tr>
    <tr>
        <td style="text-align: center; height: 39px;">
            <asp:RadioButton runat="server" GroupName="WebStyle" Checked="True" Text="默认风格" ID="RadioButton1">
            </asp:RadioButton>
        </td>
        <td style="text-align: center; height: 39px;">
            <asp:RadioButton runat="server" GroupName="WebStyle" Text="Silver" ID="RadioButton2">
            </asp:RadioButton>
        </td>
        <td style="text-align: center; height: 39px;">
            <asp:RadioButton runat="server" GroupName="WebStyle" Text="Green" ID="RadioButton3">
            </asp:RadioButton>
        </td>
        <td style="text-align: center; height: 39px;">
            <asp:RadioButton runat="server" GroupName="WebStyle" Text="Red" ID="RadioButton4">
            </asp:RadioButton>
        </td>
    </tr>
    <tr>
        <td style="text-align: center">
            <asp:Image runat="server" Height="176px" Width="177px" ID="Image5" ImageUrl="~/Images/Style/Black.png">
            </asp:Image>
        </td>
        <td style="text-align: center">
            <asp:Image runat="server" Height="176px" Width="177px" ID="Image6" 
                ImageUrl="~/Images/Style/Yellow.png">
            </asp:Image>
        </td>
        <td style="text-align: center">
            <asp:Image runat="server" Height="176px" Width="177px" ID="Image7" 
                ImageUrl="~/Images/Style/Sky.jpg">
            </asp:Image>
        </td>
        <td style="text-align: center">
            &nbsp; 
            <asp:Image runat="server" Height="176px" Width="177px" ID="Image8" 
                ImageUrl="~/Images/Style/Cloud.jpg">
            </asp:Image>
        </td>
    </tr>
    <tr>
        <td style="text-align: center; height: 37px;">
            <asp:RadioButton runat="server" GroupName="WebStyle" Text="Black" ID="RadioButton5">
            </asp:RadioButton>
        </td>
        <td style="text-align: center; height: 37px;">
            <asp:RadioButton runat="server" GroupName="WebStyle" Text="Yellow" 
                ID="RadioButton6">
            </asp:RadioButton>
        </td>
        <td style="text-align: center; height: 37px;">
            <asp:RadioButton runat="server" GroupName="WebStyle" Text="Sky" 
                ID="RadioButton7">
            </asp:RadioButton>
        </td>
        <td style="text-align: center; height: 37px;">
            <asp:RadioButton runat="server" GroupName="WebStyle" Text="Cloud" 
                ID="RadioButton8">
            </asp:RadioButton>
        </td>
    </tr>
    <tr>
        <td style="text-align: center">
            <asp:Image runat="server" Height="176px" Width="177px" ID="Image9" 
                ImageUrl="~/Images/Style/CBD.jpg">
            </asp:Image>
        </td>
        <td style="text-align: center">
            <asp:Image runat="server" Height="176px" Width="177px" ID="Image10" 
                ImageUrl="~/Images/Style/Grass.jpg">
            </asp:Image>
        </td>
        <td style="text-align: center">
            请到官网下载更多...</td>
        <td style="text-align: center">
            &nbsp;</td>
    </tr>
    <tr>
        <td style="text-align: center;height: 37px;">
            <asp:RadioButton runat="server" GroupName="WebStyle" Text="CBD" 
                ID="RadioButton9">
            </asp:RadioButton>
        </td>
        <td style="text-align: center;height: 37px;">
            <asp:RadioButton runat="server" GroupName="WebStyle" Text="Grass" 
                ID="RadioButton10">
            </asp:RadioButton>
        </td>
        <td style="text-align: center;height: 37px;">
            &nbsp;</td>
        <td style="text-align: center;height: 37px;">
            &nbsp;</td>
    </tr>
    <tr>
        <td style="text-align: left">
            &nbsp;</td>
        <td>
            &nbsp;
        </td>
        <td>
            &nbsp;
        </td>
        <td style="text-align: right">
            <asp:ImageButton runat="server" ImageUrl="~/Images/Admin/p (6).png" ID="ImageButton4"
                OnClick="ImageButton4_Click"></asp:ImageButton>
        </td>
    </tr>
    <tr>
        <td style="text-align: left; height: 48px;">
            <strong style="text-align: left">自定义网站风格模板：</strong>
        </td>
        <td style="height: 48px">
            &nbsp;
        </td>
        <td style="height: 48px">
            &nbsp;
        </td>
        <td style="height: 48px">
            &nbsp;
        </td>
    </tr>
    <tr>
        <td colspan="4" style="text-align: left">
            &nbsp;&nbsp; 网站模板是运用 DIV+CSS 
            创建而成的，如果你熟悉该技术（参照官方技术文档），或者在官方网站下载了最新的网站皮肤。你可以定义你自己的模板。使用下面工具上传自定义的模板。模板文件为ZIP格式文件。<a
                href="../UI/Default.zip"><b>[下载模板文件示例]</b></a><br />
            &nbsp;&nbsp; 1.模板ZIP压缩文件必须包含与ZIP文件同名的父文件夹。父文件夹下包含用于存储图片的Images文件夹和存储样式表的Style构成。<br />
            &nbsp;&nbsp; 2.模板样式表文件在压缩包内路径必须是：“模板文件夹\\Style\\StyleSheet.css”<br />
            &nbsp;&nbsp; 3.通过下面 “浏览” 按钮选择你的 ZIP文件<br />
            &nbsp;&nbsp; 4.点击 “确定” 完成安装皮肤
            <hr />
        </td>
    </tr>
    <tr>
        <td colspan="4" 
            style="text-align: left; background-color: #CCCCCC; height: 46px;">
            &nbsp;&nbsp;选择皮肤压缩包路径:&nbsp;
            <asp:FileUpload ID="FileUpload1" runat="server" />
            <asp:Button ID="Button1" runat="server" OnClick="Button1_Click" Text="确定" Width="79px" />
        </td>
    </tr>
    <tr>
        <td colspan="4" style="text-align: left">
            &nbsp;
        </td>
    </tr>
    <tr>
        <td colspan="4" style="text-align: left">
            <asp:Label runat="server" ID="Label4"></asp:Label>
        </td>
    </tr>
</table>

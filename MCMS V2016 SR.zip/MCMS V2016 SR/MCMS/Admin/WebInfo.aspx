﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin/Admin.master" AutoEventWireup="true"
    CodeBehind="WebInfo.aspx.cs" Inherits="MCMS.Admin.WebForm1" %>

<%@ Register Src="Style_Edit.ascx" TagName="Style_Edit" TagPrefix="uc2" %>
<%@ Register src="../WEditor/WEditor.ascx" tagname="WEditor" tagprefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="Contenthead" runat="server">
    <link href="../Style/Admin.css" rel="stylesheet" type="text/css" />
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <asp:Wizard ID="Wizard1" runat="server" Height="598px" Width="998px" ActiveStepIndex="0"
        CancelDestinationPageUrl="~/Admin/WebInfo.aspx">
        <NavigationStyle BackColor="#E6E6E6" />
        <SideBarButtonStyle Height="30px" Width="145px" />
        <SideBarStyle BackColor="#E6E6E6" VerticalAlign="Top" Width="150px" Font-Bold="False"
            HorizontalAlign="Left" CssClass="sidebar" />
        <StepStyle HorizontalAlign="Left" VerticalAlign="Top" Font-Bold="False" />
        <WizardSteps>
            <asp:WizardStep ID="WizardStep1" runat="server" Title="网站名称">
                <div class="admin_item">
                    <div class="admin_item_left">
                        网站名称：
                    </div>
                    <div class="admin_item_right">
                        <asp:TextBox ID="TextBox1" runat="server" Style="margin-bottom: 0px" Width="264px"
                            MaxLength="50">输入网站名称</asp:TextBox>
                        <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="TextBox1"
                            ErrorMessage="网站名称不能为空"></asp:RequiredFieldValidator>
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:ImageButton ID="ImageButton1" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                            OnClick="ImageButton1_Click" />
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:Label ID="Label1" runat="server"></asp:Label>
                    </div>
                </div>
            </asp:WizardStep>
            <asp:WizardStep ID="WizardStep2" runat="server" Title="网站副标题">
                <div class="admin_item">
                    <div class="admin_item_left">
                        副标题：
                    </div>
                    <div class="admin_item_right">
                        <asp:TextBox ID="TextBox3" runat="server" Style="margin-bottom: 0px" Width="264px"
                            MaxLength="50"></asp:TextBox>
                        （网站副标题字数以20字以内为宜）</div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:ImageButton ID="ImageButton2" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                            OnClick="ImageButton2_Click" />
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:Label ID="Label2" runat="server"></asp:Label>
                    </div>
                </div>
            </asp:WizardStep>
            <asp:WizardStep ID="WizardStep10" runat="server" Title="搜索关键字">
                <div class="admin_item">
                    <div class="admin_item_left">
                        关键字：
                    </div>
                    <div class="admin_item_right">
                        <asp:TextBox ID="TextBox2" runat="server" Style="margin-bottom: 0px" Width="400px"
                            MaxLength="50"></asp:TextBox>
                        （搜索关键字字数以100字以内为宜，中间用逗号隔开）</div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:ImageButton ID="ImageButton4" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                            OnClick="ImageButton4_Click" />
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:Label ID="Label4" runat="server"></asp:Label>
                    </div>
                </div>
            </asp:WizardStep>
            <asp:WizardStep ID="WizardStep11" runat="server" Title="网站简介">
                <div class="admin_item">
                    <div class="admin_item_left">
                        网站简介：
                    </div>
                    <div class="admin_item_right">
                        <asp:TextBox ID="TextBox4" runat="server" Style="margin-bottom: 0px" Width="713px"
                            MaxLength="50" Height="132px" TextMode="MultiLine"></asp:TextBox>
                        <br />
                        （简介字数不要超过500字，该简介将被搜索引擎收录）</div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:ImageButton ID="ImageButton10" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                            Height="38px" OnClick="ImageButton10_Click" />
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:Label ID="Label10" runat="server"></asp:Label>
                    </div>
                </div>
            </asp:WizardStep>
            <asp:WizardStep ID="WizardStep3" runat="server" Title="站点LOGO">
                <div class="admin_item">
                    <asp:Image ID="Image1" runat="server" Height="50px" BorderColor="White" BorderWidth="25px" BackColor="#FF99FF"  />
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        网站LOGO:
                    </div>
                    <div class="admin_item_right">
                        <asp:FileUpload ID="FileUpload1" runat="server" />
                        （推荐尺寸:200px * 60px）
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:ImageButton ID="ImageButton3" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                            OnClick="ImageButton3_Click" />
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:Label ID="Label3" runat="server"></asp:Label>
                    </div>
                </div>
            </asp:WizardStep>
            <asp:WizardStep ID="WizardStep5" runat="server" Title="内页横幅">
                <div class="admin_item">
                    <asp:Image ID="Image2" runat="server" Height="95px" BorderColor="White" BorderWidth="25px" BackColor="#FF99FF" Width="783px"  />
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        内页横幅：
                    </div>
                    <div class="admin_item_right">
                        <asp:FileUpload ID="FileUpload3" runat="server" />
                        （推荐尺寸:1000px * 150px）
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:ImageButton ID="ImageButton9" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                            OnClick="ImageButton9_Click" />
                    </div>
                </div>
                <div class="admin_item">
                    <div class="admin_item_left">
                        &nbsp;
                    </div>
                    <div class="admin_item_right">
                        <asp:Label ID="Label9" runat="server"></asp:Label>
                    </div>
                </div>
            </asp:WizardStep>
            <asp:WizardStep ID="WizardStep6" runat="server" Title="主题风格模板">
                <uc2:Style_Edit ID="Style_Edit1" runat="server" />
            </asp:WizardStep>
            <asp:WizardStep ID="WizardStep7" runat="server" Title="关于我们">
                 <div class="admin_item">
                    <uc1:WEditor ID="WEditor1" runat="server" />
                </div>
                <div class="admin_item">
                    <asp:ImageButton ID="ImageButton5" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                        OnClick="ImageButton5_Click" />
                </div>
                <div class="admin_item">
                    <asp:Label ID="Label5" runat="server"></asp:Label>
                </div>
            </asp:WizardStep>
            <asp:WizardStep ID="WizardStep8" runat="server" Title="联系信息">
                <div class="admin_item">
                    <uc1:WEditor ID="WEditor2" runat="server" />
                </div>
                <div class="admin_item">
                    <asp:ImageButton ID="ImageButton6" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                        OnClick="ImageButton6_Click" />
                </div>
                <div class="admin_item">
                    <asp:Label ID="Label6" runat="server"></asp:Label>
                </div>
            </asp:WizardStep>
            <asp:WizardStep ID="WizardStep9" runat="server" Title="底部信息">
                <div class="admin_item">
                    <uc1:WEditor ID="WEditor3" runat="server" />
                </div>
                <div class="admin_item">
                    <asp:ImageButton ID="ImageButton7" runat="server" ImageUrl="~/Images/Admin/p (6).png"
                        OnClick="ImageButton7_Click" />
                </div>
                <div class="admin_item">
                    <asp:Label ID="Label7" runat="server"></asp:Label>
                </div>
            </asp:WizardStep>
        </WizardSteps>
    </asp:Wizard>
</asp:Content>

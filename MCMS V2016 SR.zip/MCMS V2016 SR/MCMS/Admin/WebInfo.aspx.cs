﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Admin
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //获取原始数据
                CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

                string SQL = "SELECT 主标题 FROM [Style]";
                TextBox1.Text = cd.GetFirstValue(SQL).ToString();

                SQL = "SELECT 副标题 FROM [Style]";
                TextBox3.Text = cd.GetFirstValue(SQL).ToString();

                SQL = "SELECT 关键字 FROM [Style]";
                TextBox2.Text = cd.GetFirstValue(SQL).ToString();

                SQL = "SELECT 说明文字 FROM [Style]";
                TextBox4.Text = cd.GetFirstValue(SQL).ToString();

                SQL = "SELECT 关于我们 FROM [Style]";
                WEditor1.Value = cd.GetFirstValue(SQL).ToString();

                SQL = "SELECT 联系信息 FROM [Style]";
                WEditor2.Value = cd.GetFirstValue(SQL).ToString();

                SQL = "SELECT 底部信息 FROM [Style]";
                WEditor3.Value = cd.GetFirstValue(SQL).ToString();

                SQL = "SELECT LOGO FROM [Style]";
                string LogoPic= cd.GetFirstValue(SQL).ToString();
                Image1.ImageUrl = "~/Picture/Logo/" + LogoPic;

                SQL = "SELECT 内页图片 FROM [Style]";
                string PagePic = cd.GetFirstValue(SQL).ToString();
                Image2.ImageUrl = "~/Picture/PagePic/" + PagePic;
            }
        }

        /// <summary>
        /// 执行操作
        /// </summary>
        /// <param name="field"></param>
        /// <param name="Value"></param>
        public void RunSQL(string field, string Value)
        {
            //查询是否已经定义了网站信息
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

            string SQL = "SELECT COUNT(*) FROM [Style] ";
            string countNum = cd.GetFirstValue(SQL);
            if (int.Parse(countNum) == 0)//没定义数据
            {
                SQL = "INSERT INTO Style  (" + field + ") VALUES  ('" + Value + "')";
                cd.RunSqlCmd(SQL);
            }
            else
            {
                SQL = "UPDATE Style SET  " + field + " = '" + Value + "'";
                cd.RunSqlCmd(SQL);
            }
        }

        /// <summary>
        /// 网站名称
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            //查询是否已经定义了网站信息
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

            //执行查询或插入操作
            RunSQL("主标题", TextBox1.Text);
            Label1.Text = "成功操作！";

        }

        /// <summary>
        /// 网站副标题
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            //查询是否已经定义了网站信息
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

            //执行查询或插入操作
            RunSQL("副标题", TextBox3.Text);
            Label2.Text = "成功操作！";
        }

        /// <summary>
        /// 搜索关键字
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            //获取修改后的数据
            string keyWord = TextBox2.Text;

            //执行查询或插入操作
            RunSQL("关键字", keyWord);
            Label4.Text = "成功操作！";
        }

        /// <summary>
        /// 网站简介
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            //获取修改后的数据
            string description = TextBox4.Text;

            //执行查询或插入操作
            RunSQL("说明文字", description);
            Label10.Text = "成功操作！";
        }

        /// <summary>
        /// 网站LOGO
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            //上次照片
            string sendPath = @Server.MapPath("/Picture/Logo/");
            string picPath = SendFile.SendFileUpload(".jpg,.png,.gif", 1000000, sendPath, FileUpload1);

            //执行查询或插入操作
            RunSQL("LOGO", picPath);
            Image1.ImageUrl = "~/Picture/Logo/" + picPath;
            Label3.Text = "成功操作！";
        }

        /// <summary>
        /// 内页横幅图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            //上次横幅图片
            string sendPath = @Server.MapPath("/Picture/PagePic/");
            string imagePath = SendFile.SendFileUpload(".jpg,.png,.gif,.swf", 5000000, sendPath, FileUpload3);

            //执行查询或插入操作
            RunSQL("内页图片", imagePath);
            Image2.ImageUrl = "~/Picture/PagePic/" + imagePath;
            Label9.Text = "成功操作！";

        }

        /// <summary>
        /// 设置关于我们
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            //获取修改后的数据
            string aboutUs = WEditor1.Value;

            //执行查询或插入操作
            RunSQL("关于我们", aboutUs);
            Label5.Text = "成功操作！";

        }

        /// <summary>
        /// 设置联系信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            //获取修改后的数据
            string contentUs = WEditor2.Value;

            //执行查询或插入操作
            RunSQL("联系信息", contentUs);
            Label6.Text = "成功操作！";
        }

        /// <summary>
        /// 设置底部信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            //获取修改后的数据
            string footInfo = WEditor3.Value;

            //执行查询或插入操作
            RunSQL("底部信息", footInfo);
            Label7.Text = "成功操作！";

        }     
    }
}
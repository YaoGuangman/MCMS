﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Admin
{
    public partial class WebForm12 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DetailsView1_ItemDeleted(object sender, DetailsViewDeletedEventArgs e)
        {
            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/Job_Received_Edit.aspx";
            Session["Info"] = "删除成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Admin
{
    public partial class WebForm15 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/Links_Edit.aspx";
            Session["Info"] = "删除成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }

        protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/Links_Edit.aspx";
            Session["Info"] = "更新成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }

        protected void DetailsView1_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
        {
            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/Links_Edit.aspx";
            Session["Info"] = "添加成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Admin
{
    public partial class WebForm17 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //获取需要删除的职位ID
            string jobId = Request.QueryString["id"].ToString();

            //删除职位图片文件
            string SQL = @"SELECT 职位介绍 FROM  [Job] WHERE (Job_ID =" + jobId + ")";
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
            string jobText = cd.GetFirstValue(SQL).ToString();
            OperateHtml.DeleteHtmlImages(jobText);

            //删除职位
            SQL = "DELETE FROM [Job] WHERE (Job_ID = " + jobId + ")";
            cd.RunSqlCmd(SQL);

            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/Job_Edit.aspx";
            Session["Info"] = "已删除职位中的图片和记录成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }
    }
}
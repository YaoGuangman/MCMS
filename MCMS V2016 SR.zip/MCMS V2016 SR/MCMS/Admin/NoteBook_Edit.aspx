﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin/Admin.master" AutoEventWireup="true"
    CodeBehind="NoteBook_Edit.aspx.cs" Inherits="MCMS.Admin.WebForm13" %>

<asp:Content ID="Content1" ContentPlaceHolderID="Contenthead" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <asp:GridView ID="GridView1" runat="server" AllowPaging="True" AutoGenerateColumns="False"
        DataSourceID="AccessDataSource1" EnableModelValidation="True" GridLines="None" Style="text-align: left" Width="100%" CellSpacing="4" DataKeyNames="NoteBook_ID"
        OnRowDeleted="GridView1_RowDeleted">
        <Columns>
            <asp:TemplateField HeaderText="留言列表">
                <ItemTemplate>
                    <div class="control_item" style="background-color: #E6E6E6;">
                        <%#Eval("NoteBook_ID") %>楼:<%#Eval("标题") %></div>
                    <div class="control_item" style="width:930px; padding:20px;">
                        <%#Eval("正文") %>
                    </div>
                    <div class="control_item" style="text-align: right;">
                        <%#Eval ("昵称") %>在<%#Eval("发布日期") %>时发表 &nbsp;
                        <asp:LinkButton ID="DeleteBtn" Text="[删除]" CommandName="Delete" runat="server" Font-Bold="True" />
                    </div>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <RowStyle Height="40px" />
        <HeaderStyle BackColor="#333333" Font-Bold="True" ForeColor="White" Height="40px" HorizontalAlign="Left" />
        <PagerStyle BackColor="#E6E6E6" ForeColor="Black" HorizontalAlign="Right" Font-Bold="True" Font-Size="Large" Height="40px" />
    </asp:GridView>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [NoteBook] ORDER BY [NoteBook_ID] DESC" DeleteCommand="DELETE FROM NoteBook WHERE (NoteBook_ID = ?)">
    </asp:AccessDataSource>
</asp:Content>

﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin/Admin.master" AutoEventWireup="true"
    CodeBehind="Picture_Edit.aspx.cs" Inherits="MCMS.Admin.WebForm14" %>

<asp:Content ID="Content1" ContentPlaceHolderID="Contenthead" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="admin_item">
        选择文件夹:
        <asp:DropDownList ID="DropDownList1" runat="server" Width="153px">
            <asp:ListItem Value="Logo">网站LOGO文件</asp:ListItem>
            <asp:ListItem Value="Slider">主页横幅文件</asp:ListItem>
            <asp:ListItem Value="PagePic">内页横幅文件</asp:ListItem>
            <asp:ListItem Value="NewsPic">新闻图片文件</asp:ListItem>
            <asp:ListItem Value="CasePic">案例图片文件</asp:ListItem>
        </asp:DropDownList>
        <asp:Button ID="Button1" runat="server" Text="查看" OnClick="Button1_Click" Width="80px" />
        &nbsp;(点击图片执行删除操作！)
    </div>
    <div class="admin_item">
        <asp:Panel ID="Panel1" runat="server" BackColor="White" BorderColor="#CCCCCC" BorderWidth="1px"
            Height="706px" ScrollBars="Both">
            <br />
        </asp:Panel>
    </div>
</asp:Content>

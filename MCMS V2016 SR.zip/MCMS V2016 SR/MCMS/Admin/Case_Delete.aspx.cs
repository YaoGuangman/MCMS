﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Admin
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //获取案例ID和图片地址
            string caseId = Request.QueryString["caseId"].ToString();
            string picName = Request.QueryString["picPath"].ToString();

            //删除案例
            string SQL = "DELETE FROM [Case] WHERE (Case_ID = "+caseId+")";
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
            cd.RunSqlCmd(SQL);

            //删除图片文件
            if (picName != null && picName.Trim() != "")
            {
                string fullPath = "~/Picture/CasePic/" + picName;
                System.IO.File.Delete(@Server.MapPath(fullPath));
            }

            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/Case_Edit.aspx";
            Session["Info"] = "已删除案例中的图片和记录成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }
    }
}
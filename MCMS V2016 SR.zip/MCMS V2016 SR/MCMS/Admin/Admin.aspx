﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin/Admin.master" AutoEventWireup="true"
    CodeBehind="Admin.aspx.cs" Inherits="MCMS.Admin.WebForm2" %>

<asp:Content ID="Content1" ContentPlaceHolderID="Contenthead" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <table>
        <tr>
            <td class="content_admin_left">
                <asp:Button ID="Button1" runat="server" PostBackUrl="~/Default.aspx" Text="网站首页"
                    Width="96px" /><br />
                <asp:Button ID="Button2" runat="server" PostBackUrl="http://www.cnblogs.com/mane/"
                    Text="技术博客" Width="96px" /><br />
                <asp:Button ID="Button4" runat="server" PostBackUrl="http://weibo.com/manesoft"
                    Text="新浪微博" Width="96px" /><br />
                <asp:Button ID="Button3" runat="server" PostBackUrl="mailto:mane.yao@qq.com"
                    Text="联系我们" Width="96px" /><br />
            </td>
            <td class="content_admin_right" style="width:800px; padding:20px;">
                <strong>软件介绍：</strong><hr style="color: #00CC00; height: 1px" />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; MCMS是一款开源的CMS管理系统，软件以简洁实用为己任。不同于其他CMS,软件由ASP.NET开发，数据库为ACCESS，使用.NET
                FrameWork 2.0 版。<br />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CMS是Content Management System的缩写，意为&quot;内容管理系统&quot;，它具有许多基于模板的优秀设计，可以加快网站开发的速度和减少开发的成本。简而言之，CMS就是可以让你不需要学习复杂的建站技术，不需要学习太多复杂的<a
                    href="http://baike.baidu.com/view/692.htm" target="_blank">HTML</a>语言，你就能够利用CMS构建出一个风格统一功能强大的专业网站。<br />
                <br />
                运行环境：.NET FrameWork 2.0<br />
                开发语言：C#、ASP.NET<br />
                开发软件：Visual Studio 2010<br />
                数据库：ACCESS<br />
                开发时间:2014-6-17<br />
                技术博客：http://www.cnblogs.com/mane/
                <br />
                作者：Yao,Mane
                <br />
                QQ:281210164
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
            </td>
        </tr>
    </table>
</asp:Content>

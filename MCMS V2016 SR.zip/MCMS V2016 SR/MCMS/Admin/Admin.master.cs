﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Admin
{
    public partial class Admin1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null && Session["UserPwd"] != null)
            {
                //获取用户名和密码
                string userName = Session["UserName"].ToString();
                string userPwd = Session["UserPwd"].ToString();
                //密码加密
                userPwd = EncryptStringClass.EncryptString(userPwd, "49316349");

                //查找是否有管理员权限
                String SQL = "SELECT Role FROM [User] WHERE  (User_Name = '" + userName + "') AND (User_Pwd = '" + userPwd + "')";
                CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
                string role = cd.GetFirstValue(SQL);
                if (role != "True")
                {
                    //跳转到指定页面
                    Session["GotoURL"] = "~/Register/Login.aspx";
                    Session["Info"] = "对不起，您的帐户不具有管理员权限，请返回登录";
                    Response.Redirect("~/Register/MessageBox.aspx");
                }
            }
            else
            {
                //跳转到指定页面
                Session["GotoURL"] = "~/Register/Login.aspx";
                Session["Info"] = "对不起，您目前为游客，请返回登录";
                Response.Redirect("~/Register/MessageBox.aspx");
            }
        }
    }
}
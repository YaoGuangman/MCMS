﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Admin
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //获取原始数据
                if (Request.QueryString["id"] != null)//存在QueryString
                {
                    //获取原始的数据到输入框中
                    string CaseID = Request.QueryString["id"].ToString();
                    CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

                    string SQL = "SELECT 标题 FROM [Case_Type_View] WHERE (Case_ID = " + CaseID + ")";
                    TextBox1.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 所属项目 FROM [Case_Type_View] WHERE (Case_ID = " + CaseID + ")";
                    DropDownList1.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 备注 FROM [Case_Type_View] WHERE (Case_ID = " + CaseID + ")";
                    string strBody = cd.GetFirstValue(SQL).ToString();
                    TextBox4.Text = OperateHtml.ReplaceHtmlText(strBody, "<br/>", "\r\n");
                }
            }
        }

        /// <summary>
        /// 添加或编辑案例
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

            //获取图片地址
            string sendPath = Server.MapPath("~/Picture/CasePic/"); 
            string picPath = SendFile.SendFileUpload(".jpg,.png,.gif", 1000000, sendPath, FileUpload1);

            //查询所属项目Type_ID
            string SQL = "SELECT Type_ID FROM Case_Type WHERE 所属项目='" + DropDownList1.Text + "'";
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
            string typeID = cd.GetFirstValue(SQL);

            //替换textArea中的换行符
            string strBody = OperateHtml.ReplaceHtmlText(TextBox4.Text, "\r\n", "<br/>");

            //添加或更新新闻
            if (Request.QueryString["id"] != null)//存在QueryString
            {
                //所编辑的案例ID
                string CaseID = Request.QueryString["id"].ToString();

                //如果图片没有选择则获取原始图片
                if (picPath == "" || picPath ==null)
                {
                    SQL = "SELECT 图片地址  FROM [Case_Type_View] WHERE (Case_ID = " + CaseID + ")";
                    picPath = cd.GetFirstValue(SQL).ToString();
                }

                //更新
                SQL = "UPDATE  [Case] SET  标题 = '" +
                    TextBox1.Text + "', Type_ID = " +
                    typeID + ", 发布日期 = '" +
                    DateTime.Now.ToString() + "', 图片地址 = '" +
                    picPath + "', 备注 = '" +
                    strBody + "' WHERE  (Case_ID = " +
                    CaseID + ")";
                cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
                cd.RunSqlCmd(SQL);

                //跳转到指定页面
                Session["GotoURL"] = "~/Admin/Case_Edit.aspx";
                Session["Info"] = "案例更新成功";
                Response.Redirect("~/Register/MessageBox.aspx");

            }
            else//不存在QueryString
            {
                //插入
                SQL = "INSERT INTO [Case]  (标题, Type_ID, 发布日期, 图片地址, 备注) VALUES ('" +
                    TextBox1.Text + "', '" +
                    typeID + "', '" +
                    DateTime.Now.ToString() + "','" +
                    picPath + "', '" +
                    strBody + "')";

                cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
                cd.RunSqlCmd(SQL);

                //跳转到指定页面
                Session["GotoURL"] = "~/Admin/Case_Edit.aspx";
                Session["Info"] = "添加案例成功";
                Response.Redirect("~/Register/MessageBox.aspx");
            }

        }
    }
}
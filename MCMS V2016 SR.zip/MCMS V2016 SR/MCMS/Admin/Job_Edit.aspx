﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin/Admin.master" AutoEventWireup="true"
    CodeBehind="Job_Edit.aspx.cs" Inherits="MCMS.Admin.WebForm10" %>

<asp:Content ID="Content1" ContentPlaceHolderID="Contenthead" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <table>
        <tr>
            <td class="content_admin_left">
                <asp:Button ID="Button4" runat="server" PostBackUrl="~/Admin/Job_Add.aspx" Text="添加职位"
                    Width="96px" /><br />
                <asp:Button ID="Button2" runat="server" PostBackUrl="~/Admin/Job_Edit.aspx" Text="管理职位"
                    Width="96px" /><br />
                <asp:Button ID="Button5" runat="server" PostBackUrl="~/Admin/Job_Received_Edit.aspx"
                    Text="应聘信息" Width="96px" /><br />
            </td>
            <td class="content_admin_right">
                <asp:GridView ID="GridView1" runat="server" AllowPaging="True" AutoGenerateColumns="False"
                    BackColor="White" BorderColor="#CCCCCC" BorderStyle="None" BorderWidth="1px"
                    CellPadding="4" DataKeyNames="Job_ID" DataSourceID="AccessDataSource1" EnableModelValidation="True"
                    ForeColor="Black" GridLines="Horizontal" PageSize="20" Width="100%" OnRowDeleted="GridView1_RowDeleted"
                    OnRowUpdated="GridView1_RowUpdated">
                    <Columns>
                        <asp:TemplateField HeaderText="操作">
                            <ItemTemplate>
                                <a href="Job_Add.aspx?id=<%#Eval("Job_ID") %>">编辑</a>
                                <a href="Job_Delete.aspx?id=<%#Eval("Job_ID") %>">删除</a>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="职位">
                            <ItemTemplate>
                                <a href="../Job_Body.aspx?id=<%#Eval("Job_ID") %>">
                                    <%#Eval("职位名称") %></a>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <RowStyle Height="40px" />
                    <HeaderStyle BackColor="#333333" Font-Bold="True" ForeColor="White" Height="40px" HorizontalAlign="Left" />
                    <PagerStyle BackColor="#E6E6E6" ForeColor="Black" HorizontalAlign="Right" Font-Bold="True" Font-Size="Large" Height="40px" />
                </asp:GridView>
                <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
                    SelectCommand="SELECT * FROM [Job] ORDER BY [Job_ID] DESC" DeleteCommand="DELETE FROM Job WHERE (Job_ID = ?)"></asp:AccessDataSource>
            </td>
        </tr>
    </table>
</asp:Content>

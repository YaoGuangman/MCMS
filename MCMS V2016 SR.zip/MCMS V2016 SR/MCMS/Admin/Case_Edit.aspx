﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin/Admin.master" AutoEventWireup="true"
    CodeBehind="Case_Edit.aspx.cs" Inherits="MCMS.Admin.WebForm7" %>

<asp:Content ID="Content1" ContentPlaceHolderID="Contenthead" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <table>
        <tr>
            <td class="content_admin_left">
                <asp:Button ID="Button4" runat="server" PostBackUrl="~/Admin/Case_Type.aspx" Text="产品分类"
                    Width="96px" /><br />
                <asp:Button ID="Button2" runat="server" PostBackUrl="~/Admin/Case_Add.aspx" Text="添加产品"
                    Width="96px" /><br />
                <asp:Button ID="Button3" runat="server" PostBackUrl="~/Admin/Case_Edit.aspx" Text="管理产品"
                    Width="96px" /><br />
            </td>
            <td class="content_admin_right">
                <asp:GridView ID="GridView1" runat="server" AllowPaging="True" AutoGenerateColumns="False"
                    BackColor="White" BorderColor="#CCCCCC" BorderStyle="None" BorderWidth="1px"
                    CellPadding="4" DataKeyNames="Case_ID" DataSourceID="AccessDataSource1" EnableModelValidation="True"
                    GridLines="Horizontal" PageSize="20" Width="100%" ForeColor="Black">
                    <Columns>
                        <asp:TemplateField HeaderText="操作">
                            <ItemTemplate>
                                <a href="Case_Add.aspx?id=<%#Eval("Case_ID") %>">编辑</a>
                                <a href="Case_Delete.aspx?caseId=<%#Eval("Case_ID") %>&picPath=<%#Eval("图片地址") %>">删除</a>&nbsp;
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="案例名称">
                            <ItemTemplate>
                                <a href="../Case_Body.aspx?id=<%#Eval("Case_ID") %>">
                                    <%#Eval("标题") %></a>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <RowStyle Height="40px" />
                    <HeaderStyle BackColor="#333333" Font-Bold="True" ForeColor="White" Height="40px" HorizontalAlign="Left" />
                    <PagerStyle BackColor="#E6E6E6" ForeColor="Black" HorizontalAlign="Right" Font-Bold="True" Font-Size="Large" Height="40px" />
                </asp:GridView>
                <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
                    SelectCommand="SELECT * FROM [Case] ORDER BY [Case_ID] DESC" DeleteCommand="DELETE FROM [Case] WHERE (Case_ID = ?)"></asp:AccessDataSource>
            </td>
        </tr>
    </table>
</asp:Content>

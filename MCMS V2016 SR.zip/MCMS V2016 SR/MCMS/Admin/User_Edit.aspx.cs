﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;//
using System.Data;//

namespace MCMS.Admin
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string SQL = "SELECT * FROM [User] WHERE (User_Name = '" + TextBox1.Text + "')";
            AccessDataSource1.SelectCommand = SQL;
            DetailsView1.DataBind();
            DetailsView1.AutoGenerateEditButton = false;

        }

        protected void DetailsView1_ItemDeleted(object sender, DetailsViewDeletedEventArgs e)
        {
            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/User_Edit.aspx";
            Session["Info"] = "删除成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }

        protected void DetailsView1_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
        {
            //跳转到指定页面
            Session["GotoURL"] = "~/Admin/User_Edit.aspx";
            Session["Info"] = "更新成功";
            Response.Redirect("~/Register/MessageBox.aspx");
        }
    }
}
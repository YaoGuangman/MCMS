﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SharpZipLib;//

namespace MCMS.Admin
{
    public partial class Style_Edit : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 执行操作
        /// </summary>
        /// <param name="field"></param>
        /// <param name="Value"></param>
        public void RunSQL(string field, string Value)
        {
            //查询是否已经定义了网站信息
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

            string SQL = "SELECT COUNT(*) FROM [Style] ";
            string countNum = cd.GetFirstValue(SQL);
            if (int.Parse(countNum) == 0)//没定义数据
            {
                SQL = "INSERT INTO Style  (" + field + ") VALUES  ('" + Value + "')";
                cd.RunSqlCmd(SQL);
            }
            else
            {
                SQL = "UPDATE Style SET  " + field + " = '" + Value + "'";
                cd.RunSqlCmd(SQL);
            }
        }

        /// <summary>
        /// 修改网站风格
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {

            //设置模板的位置
            string styleFilePath = "";
            if (RadioButton1.Checked == true)
            {
                styleFilePath = "\\Default\\Style\\StyleSheet.css";
            }
            else if (RadioButton2.Checked == true)
            {
                styleFilePath = "\\Sliver\\Style\\StyleSheet.css";
            }
            else if (RadioButton3.Checked == true)
            {
                styleFilePath = "\\Green\\Style\\StyleSheet.css";
            }
            else if (RadioButton4.Checked == true)
            {
                styleFilePath = "\\Red\\Style\\StyleSheet.css";
            }
            else if (RadioButton5.Checked == true)
            {
                styleFilePath = "\\Black\\Style\\StyleSheet.css";
            }
            else if (RadioButton6.Checked == true)
            {
                styleFilePath = "\\Yellow\\Style\\StyleSheet.css";
            }
            else if (RadioButton7.Checked == true)
            {
                styleFilePath = "\\Sky\\Style\\StyleSheet.css";
            }
            else if (RadioButton8.Checked == true)
            {
                styleFilePath = "\\Cloud\\Style\\StyleSheet.css";
            }
            else if (RadioButton9.Checked == true)
            {
                styleFilePath = "\\CBD\\Style\\StyleSheet.css";
            }
            else if (RadioButton10.Checked == true)
            {
                styleFilePath = "\\Grass\\Style\\StyleSheet.css";
            }

            //执行查询或插入操作
            RunSQL("主题风格", styleFilePath);
            Label4.Text = "成功操作！";
        }

        /// <summary>
        /// 自定义皮肤
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click(object sender, EventArgs e)
        {
            //获取ZIP文件
            string sendPath = Server.MapPath("~/UI/");
            string styleName = FileUpload1.FileName;//原始文件名
            string fileName= SendFile.SendFileUpload(".zip", 100000000, sendPath, FileUpload1);//上传后并获取上传后文件名（上传后被名字会自动修改）
            
            //解压缩
            string sourceDirectory = sendPath + fileName;
            string saveDirectory = sendPath;
            SharpZipClass.UNZipFile(sourceDirectory, saveDirectory,"");

            //获取css文件路径
            string styleFilePath = "\\" + styleName.Substring(0, styleName.LastIndexOf(".")) + "\\Style\\StyleSheet.css";

            //执行查询或插入操作
            RunSQL("主题风格", styleFilePath);
            Label4.Text = "成功操作！";
        }
    }
}
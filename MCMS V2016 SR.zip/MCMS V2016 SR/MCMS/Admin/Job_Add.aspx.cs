﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Admin
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                TextBox2.Text = DateTime.Now.ToShortDateString();
                //获取原始数据
                if (Request.QueryString["id"] != null)//不存在QueryString
                {
                    //获取原始的数据到输入框中
                    string jobID = Request.QueryString["id"].ToString();
                    CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

                    string SQL = "SELECT 职位名称 FROM [Job] WHERE (Job_ID = " + jobID + ")";
                    TextBox1.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 有效日期 FROM [Job] WHERE (Job_ID = " + jobID + ")";
                    TextBox2.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 职位介绍 FROM [Job] WHERE (Job_ID = " + jobID + ")";
                    WEditor1.Value = cd.GetFirstValue(SQL).ToString();
                }
            }
        }

        /// <summary>
        /// 更新或添加职位
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            //添加或更新新闻
            if (Request.QueryString["id"] != null)//存在QueryString
            {
                //更新
                string jobID = Request.QueryString["id"].ToString();
                string SQL = "UPDATE  Job SET  职位名称 = '" +
                    TextBox1.Text + "', 有效日期= '" +
                    TextBox2.Text + "', 职位介绍 = '" +
                    WEditor1.Value + "' WHERE   (Job.Job_ID = " +
                    jobID + ")";
                CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
                cd.RunSqlCmd(SQL);

                //跳转到指定页面
                Session["GotoURL"] = "~/Admin/Job_Edit.aspx";
                Session["Info"] = "职位更新成功";
                Response.Redirect("~/Register/MessageBox.aspx");

            }
            else//不存在QueryString
            {
                //编辑
                string SQL = "INSERT INTO Job (职位名称, 有效日期, 职位介绍) VALUES   ('" +
                    TextBox1.Text.Trim() + "', '" +
                    TextBox2.Text.Trim() + "', '" +
                    WEditor1.Value + "')";

                CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
                cd.RunSqlCmd(SQL);

                //跳转到指定页面
                Session["GotoURL"] = "~/Admin/Job_Edit.aspx";
                Session["Info"] = "添加职位成功";
                Response.Redirect("~/Register/MessageBox.aspx");
            }
        }
    }
}
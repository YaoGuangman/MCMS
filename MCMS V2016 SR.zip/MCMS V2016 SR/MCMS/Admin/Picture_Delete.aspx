﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Register/Register.Master" AutoEventWireup="true"
    CodeBehind="Picture_Delete.aspx.cs" Inherits="MCMS.Register.WebForm7" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div style="height: 300px; padding-top: 150px; text-align: center; vertical-align: middle; line-height: 30px;">
        <p style="text-align: center">
            你确定要删除图片文件吗？删除之后不可以恢复！
        </p>
        <p style="text-align: center">
            <asp:Button ID="Button1" runat="server" OnClick="Button1_Click" Text="确定" Width="55px" />
            &nbsp;
        <asp:Button ID="Button2" runat="server" PostBackUrl="~/Admin/Picture_Edit.aspx" Text="返回"
            Width="55px" />
        </p>
    </div>
</asp:Content>

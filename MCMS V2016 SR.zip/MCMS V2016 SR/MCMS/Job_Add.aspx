﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Page.master" AutoEventWireup="true"
    CodeBehind="Job_Add.aspx.cs" Inherits="MCMS.WebForm9" %>

<%@ Register Src="UserControl/Pages/Job_Add.ascx" TagName="Job_Add" TagPrefix="uc1" %>
<asp:Content ID="Content2" ContentPlaceHolderID="WebSiteHead" runat="server">
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="content_title">
        <strong>我要应聘</strong>
    </div>
    <div class="content_body">
        <uc1:Job_Add ID="Job_Add1" runat="server" />
    </div>
</asp:Content>

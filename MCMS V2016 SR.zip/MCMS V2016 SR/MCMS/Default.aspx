﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Main.Master" AutoEventWireup="true"
    CodeBehind="Default.aspx.cs" Inherits="MCMS.WebForm1" %>

<%@ Register Src="UserControl/Index/Type.ascx" TagName="Type" TagPrefix="uc2" %>
<%@ Register Src="UserControl/Index/News.ascx" TagName="News" TagPrefix="uc3" %>
<%@ Register Src="UserControl/Index/About.ascx" TagName="About" TagPrefix="uc4" %>
<%@ Register Src="UserControl/Index/Case.ascx" TagName="Case" TagPrefix="uc5" %>
<%@ Register Src="UserControl/Index/Links.ascx" TagName="Links" TagPrefix="uc6" %>
<%@ Register Src="UserControl/Index/Content.ascx" TagName="Content" TagPrefix="uc7" %>
<%@ Register src="UserControl/Index/Slider.ascx" tagname="Slider" tagprefix="uc8" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div id="content_top">
        <uc8:Slider ID="Slider1" runat="server" />
    </div>
    <div id="content_bottom">
        <div id="content_left">
            <div class="content_title">
                <strong>产品分类</strong>
            </div>
            <div class="content_body">
                <uc2:Type ID="Type1" runat="server" />
            </div>
            <div class="content_title">
                <strong>新闻动态</strong> <a href="News.aspx">&gt;&gt;更多</a>
            </div>
            <div class="content_body">
                <uc3:News ID="News1" runat="server" />
            </div>
            <div class="content_title">
                <strong>联系我们</strong>
            </div>
            <div class="content_body">
                <uc7:Content ID="Content3" runat="server" />
            </div>
        </div>
        <div id="content_right">
            <div class="content_title">
                <strong>关于我们</strong> <a href="About.aspx">&gt;&gt;详情</a>
            </div>
            <div class="content_body">
                <uc4:About ID="About1" runat="server" TrimLenth="360" />
            </div>
            <div class="content_title">
                <strong>最新产品</strong> <a href="Case.aspx">&gt;&gt;更多</a>
            </div>
            <div class="content_body">
                <uc5:Case ID="Case1" runat="server" />
            </div>
            <div class="content_title">
                <strong>友情链接</strong>
            </div>
            <div class="content_body">
                <uc6:Links ID="Links1" runat="server" />
            </div>
        </div>
    </div>
</asp:Content>

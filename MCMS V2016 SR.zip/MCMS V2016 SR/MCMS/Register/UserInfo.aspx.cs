﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Register
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //验证是否已经登录会员
            if (Session["UserName"] == null || Session["UserPwd"] == null)
            {
                //跳转到指定页面
                Session["GotoURL"] = "~/Register/Login.aspx";
                Session["Info"] = "对不起，您目前为游客，请返回登录";
                Response.Redirect("~/Register/MessageBox.aspx");
            }
        }
    }
}
﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Register/Register.Master" AutoEventWireup="true"
    CodeBehind="FindPwd.aspx.cs" Inherits="MCMS.Register.WebForm6" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="register_item">
        <img alt="" src="../Images/Register/p (11).png"  style="border-top-style: solid; border-top-width: 20px; border-top-color: #FFFFFF;"/>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            用户名:
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox1" runat="server" MaxLength="50"></asp:TextBox>
            <asp:RequiredFieldValidator ID="RequiredFieldValidator5" runat="server" ControlToValidate="TextBox1"
                ErrorMessage="用户名不能为空"></asp:RequiredFieldValidator>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            密保问题:
        </div>
        <div class="register_item_right">
            <asp:DropDownList ID="DropDownList1" runat="server" Height="21px" Width="145px">
                <asp:ListItem>我爸爸的生日？</asp:ListItem>
                <asp:ListItem>我妈妈的生日？</asp:ListItem>
                <asp:ListItem>我配偶的生日？</asp:ListItem>
                <asp:ListItem>我爸爸的名字？</asp:ListItem>
                <asp:ListItem>我妈妈的名字？</asp:ListItem>
                <asp:ListItem>我配偶的名字？</asp:ListItem>
                <asp:ListItem>我的生日？</asp:ListItem>
                <asp:ListItem>我的名字？</asp:ListItem>
                <asp:ListItem>我的出生地？</asp:ListItem>
                <asp:ListItem>我的计算机名字？</asp:ListItem>
                <asp:ListItem>我小学班主任名字？</asp:ListItem>
                <asp:ListItem>我初中班主任名字？</asp:ListItem>
                <asp:ListItem>我高中班主任名字？</asp:ListItem>
                <asp:ListItem>我最喜欢的东西是？</asp:ListItem>
                <asp:ListItem>我最喜欢的人是？</asp:ListItem>
                <asp:ListItem>我最喜欢看的书是？</asp:ListItem>
                <asp:ListItem>我的手机号码是？</asp:ListItem>
                <asp:ListItem>我毕业的学校是？</asp:ListItem>
            </asp:DropDownList>
            <asp:RequiredFieldValidator ID="RequiredFieldValidator6" runat="server" ControlToValidate="DropDownList1"
                ErrorMessage="密保问题不能为空"></asp:RequiredFieldValidator>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            密保答案:
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox12" runat="server" MaxLength="50"></asp:TextBox>
            <asp:RequiredFieldValidator ID="RequiredFieldValidator7" runat="server" ControlToValidate="TextBox12"
                ErrorMessage="密保答案不能为空"></asp:RequiredFieldValidator>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            &nbsp;
        </div>
        <div class="register_item_right">
            <asp:ImageButton ID="ImageButton3" runat="server" ImageUrl="~/Images/Register/p (7).png"
                OnClick="ImageButton3_Click" />
        </div>
    </div>
</asp:Content>

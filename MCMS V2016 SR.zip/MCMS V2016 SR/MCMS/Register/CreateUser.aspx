﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Register/Register.Master" AutoEventWireup="true"
    CodeBehind="CreateUser.aspx.cs" Inherits="MCMS.Register.WebForm2" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="register_item">
        <img alt="" src="../Images/Register/p (0).png"  style="border-top-style: solid; border-top-width: 20px; border-top-color: #FFFFFF;"/>
    </div>
    <div class="register_item">
        <img alt="" src="../Images/Register/dot3.gif" /><strong> 必填信息</strong>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            用户名：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox1" runat="server" MaxLength="50"></asp:TextBox>
            <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="TextBox1"
                ErrorMessage="用户名不能为空"></asp:RequiredFieldValidator>
            &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server"
                ControlToValidate="TextBox1" ErrorMessage="必须由3-12个英文或数字组成" ValidationExpression="[\w\-]{3,12}"></asp:RegularExpressionValidator>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            密码：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox2" runat="server" TextMode="Password" MaxLength="50"></asp:TextBox>
            <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ControlToValidate="TextBox2"
                ErrorMessage="密码不能为空"></asp:RequiredFieldValidator>
            &nbsp; <asp:RegularExpressionValidator ID="RegularExpressionValidator12" runat="server"
                ControlToValidate="TextBox2" ErrorMessage="必须由3-12个任意字符组成" ValidationExpression="[\s\S]{3,12}"></asp:RegularExpressionValidator>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            重复密码：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox3" runat="server" TextMode="Password" MaxLength="50"></asp:TextBox>
            <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" ControlToValidate="TextBox3"
                ErrorMessage="密码不能为空"></asp:RequiredFieldValidator>
            &nbsp;<asp:CompareValidator ID="CompareValidator1" runat="server" ControlToCompare="TextBox2"
                ControlToValidate="TextBox3" ErrorMessage="两次输入的密码不一致"></asp:CompareValidator>
            &nbsp; <asp:RegularExpressionValidator ID="RegularExpressionValidator11" runat="server"
                ControlToValidate="TextBox3" ErrorMessage="必须由3-12个任意字符组成" ValidationExpression="[\s\S]{3,12}"></asp:RegularExpressionValidator>
        </div>
    </div>
    <div class="register_item">
        <img alt="" src="../Images/Register/dot3.gif" /><strong> 密保信息</strong>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            密保问题：
        </div>
        <div class="register_item_right">
            <asp:DropDownList ID="DropDownList1" runat="server" Height="21px" Width="145px">
                <asp:ListItem>我爸爸的生日？</asp:ListItem>
                <asp:ListItem>我妈妈的生日？</asp:ListItem>
                <asp:ListItem>我配偶的生日？</asp:ListItem>
                <asp:ListItem>我爸爸的名字？</asp:ListItem>
                <asp:ListItem>我妈妈的名字？</asp:ListItem>
                <asp:ListItem>我配偶的名字？</asp:ListItem>
                <asp:ListItem>我的生日？</asp:ListItem>
                <asp:ListItem>我的名字？</asp:ListItem>
                <asp:ListItem>我的出生地？</asp:ListItem>
                <asp:ListItem>我的计算机名字？</asp:ListItem>
                <asp:ListItem>我小学班主任名字？</asp:ListItem>
                <asp:ListItem>我初中班主任名字？</asp:ListItem>
                <asp:ListItem>我高中班主任名字？</asp:ListItem>
                <asp:ListItem>我最喜欢的东西是？</asp:ListItem>
                <asp:ListItem>我最喜欢的人是？</asp:ListItem>
                <asp:ListItem>我最喜欢看的书是？</asp:ListItem>
                <asp:ListItem>我的手机号码是？</asp:ListItem>
                <asp:ListItem>我毕业的学校是？</asp:ListItem>
            </asp:DropDownList>
            （设置密保可以找回丢失的密码）
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            密保答案：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox13" runat="server" MaxLength="50"></asp:TextBox>
        </div>
    </div>
    <div class="register_item">
        <img alt="" src="../Images/Register/dot3.gif" /><strong> 选填信息</strong>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            昵称：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox4" runat="server" MaxLength="50"></asp:TextBox>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            性别：
        </div>
        <div class="register_item_right">
            <asp:RadioButton ID="RadioButton1" GroupName="Sex" runat="server" Text="男" Checked="True" />
            &nbsp;
            <asp:RadioButton ID="RadioButton2" GroupName="Sex" runat="server" Text="女" />
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            年龄：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox5" runat="server" MaxLength="3"></asp:TextBox>
            <asp:RegularExpressionValidator ID="RegularExpressionValidator4" runat="server" ControlToValidate="TextBox5"
                ErrorMessage="年龄输错了" ValidationExpression="1[0-2]\d|\d{1,2}"></asp:RegularExpressionValidator>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            籍贯：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox6" runat="server" MaxLength="50"></asp:TextBox>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            电话：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox7" runat="server" MaxLength="50"></asp:TextBox>
            <asp:RegularExpressionValidator ID="RegularExpressionValidator9" runat="server" ControlToValidate="TextBox7"
                ErrorMessage="只能输入数字(固话：037766666666，手机：13222222222)" ValidationExpression="^[0-9]*$"></asp:RegularExpressionValidator>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            QQ：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox8" runat="server" MaxLength="50"></asp:TextBox>
            <asp:RegularExpressionValidator ID="RegularExpressionValidator6" runat="server" ControlToValidate="TextBox8"
                ErrorMessage="只能输入数字" ValidationExpression="^[0-9]*$"></asp:RegularExpressionValidator>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            Email：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox9" runat="server" MaxLength="255"></asp:TextBox>
            <asp:RegularExpressionValidator ID="RegularExpressionValidator7" runat="server" ControlToValidate="TextBox9"
                ErrorMessage="电子信箱格式错误" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:RegularExpressionValidator>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            个人主页：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox10" runat="server" MaxLength="255"></asp:TextBox>
            <asp:RegularExpressionValidator ID="RegularExpressionValidator8" runat="server" ControlToValidate="TextBox10"
                ErrorMessage="网址输入有误" ValidationExpression="http(s)?://([\w-]+\.)+[\w-]+(/[\w- ./?%&amp;=]*)?"></asp:RegularExpressionValidator>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            自我介绍：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox12" runat="server" Width="480px" MaxLength="10" Height="88px"
                TextMode="MultiLine"></asp:TextBox>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            &nbsp;
        </div>
        <div class="register_item_right">
            <asp:ImageButton ID="ImageButton1" runat="server" ImageUrl="~/Images/Register/p (7).png"
                OnClick="ImageButton1_Click" />
        </div>
    </div>
</asp:Content>

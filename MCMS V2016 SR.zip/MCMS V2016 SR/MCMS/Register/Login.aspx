﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Register/Register.Master" AutoEventWireup="true"
    CodeBehind="Login.aspx.cs" Inherits="MCMS.Register.WebForm1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="register_item">
        <img alt="" src="../Images/Register/p%20(10).png" style="border-top-style: solid; border-top-width: 20px; border-top-color: #FFFFFF;" />
        <a href="CreateUser.aspx">
            <img alt="" src="../Images/Register/p%20(1).png" style="border-style: solid; border-width: 20px 0px 0px 0px; border-color: #FFFFFF" />
        </a>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            用户名:
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox1" runat="server" Width="239px" MaxLength="50"></asp:TextBox>
            <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="TextBox1"
                ErrorMessage="用户名不能为空"></asp:RequiredFieldValidator>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            密码：
        </div>
        <div class="register_item_right">
            <asp:TextBox ID="TextBox2" runat="server" Width="239px" TextMode="Password" MaxLength="50"></asp:TextBox>
            <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ControlToValidate="TextBox2"
                ErrorMessage="密码不能为空"></asp:RequiredFieldValidator>
            &nbsp;
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            &nbsp;
        </div>
        <div class="register_item_right">
            <asp:CheckBox ID="CheckBox1" runat="server" Text="记住登陆信息" />&nbsp;&nbsp;|&nbsp;&nbsp;<a href="FindPwd.aspx">忘记密码？</a>
        </div>
    </div>
    <div class="register_item">
        <div class="register_item_left">
            &nbsp;
        </div>
        <div class="register_item_right">
            <asp:ImageButton ID="ImageButton1" runat="server" ImageUrl="~/Images/Register/p (3).png"
                OnClick="ImageButton1_Click" Style="height: 38px" />
        </div>
    </div>
</asp:Content>

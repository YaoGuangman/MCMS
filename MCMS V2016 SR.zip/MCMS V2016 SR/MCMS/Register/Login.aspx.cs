﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Register
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //读取cookie,如果用户保存了登录信息则登录
            if (Request.Cookies["UserName"] != null)
            {
                //保存用户信息为缓存
                Session["UserName"] = Request.Cookies["UserName"].Value;
                Session["UserPwd"] = Request.Cookies["UserPwd"].Value;
                Response.Redirect("~/Register/UserInfo.aspx");
            }
        }

        /// <summary>
        /// 登录网站
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

            //加密用户输入的密码数比对数据库
            string strPwd = EncryptStringClass.EncryptString(TextBox2.Text.Trim(), "49316349");
            //操作数据库
            string SQL = "SELECT COUNT(*) FROM [User]  WHERE (User_Name = '" + TextBox1.Text + "') AND (User_Pwd = '" + strPwd + "')";
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
            string countNum = cd.GetFirstValue(SQL);

            //登录操作
            if (int.Parse(countNum) > 0)
            {
                //写入session
                Session["UserName"] = TextBox1.Text;
                Session["UserPwd"] = TextBox2.Text;

                //保存用户信息为cookie
                if (CheckBox1.Checked)
                {
                    Response.Cookies["UserName"].Value = TextBox1.Text.Trim();
                    Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(7);
                    Response.Cookies["UserPwd"].Value = TextBox2.Text.Trim();
                    Response.Cookies["UserPwd"].Expires = DateTime.Now.AddDays(7);
                }

                //跳转到指定页面
                Session["GotoURL"] = "~/Register/UserInfo.aspx";
                Session["Info"] = "欢迎您：" + TextBox1.Text + "登录成功";
                Response.Redirect("~/Register/MessageBox.aspx");
            }
            else
            {
                //跳转到指定页面
                Session["GotoURL"] = "~/Register/Login.aspx";
                Session["Info"] = "登录失败，请检查您的用户名或密码";
                Response.Redirect("~/Register/MessageBox.aspx");
            }
        }
    }
}
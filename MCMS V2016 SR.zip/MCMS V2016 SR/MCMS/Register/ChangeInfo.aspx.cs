﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Register
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null && Session["UserPwd"] != null)
            {
                if (!IsPostBack)
                {
                    //获取原始的数据到输入框中
                    string UserID = Request.QueryString["UserID"].ToString();
                    CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));

                    string SQL = "SELECT 昵称 FROM [User] WHERE (User_ID = " + UserID + ")";
                    TextBox4.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 年龄 FROM [User] WHERE (User_ID = " + UserID + ")";
                    TextBox5.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 籍贯 FROM [User] WHERE (User_ID = " + UserID + ")";
                    TextBox6.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 电话 FROM [User] WHERE (User_ID = " + UserID + ")";
                    TextBox7.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT IM FROM [User] WHERE (User_ID = " + UserID + ")";
                    TextBox8.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT Email FROM [User] WHERE (User_ID = " + UserID + ")";
                    TextBox9.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 个人主页 FROM [User] WHERE (User_ID = " + UserID + ")";
                    TextBox10.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 自我介绍 FROM [User] WHERE (User_ID = " + UserID + ")";
                    string strBody = cd.GetFirstValue(SQL).ToString();
                    TextBox12.Text = OperateHtml.ReplaceHtmlText(strBody, "<br/>", "\r\n");

                    SQL = "SELECT 密保问题 FROM [User] WHERE (User_ID = " + UserID + ")";
                    DropDownList1.Text = cd.GetFirstValue(SQL).ToString();

                    SQL = "SELECT 密保答案 FROM [User] WHERE (User_ID = " + UserID + ")";
                    TextBox13.Text = cd.GetFirstValue(SQL).ToString();
                }
            }
            else
            {
                //跳转到指定页面
                Session["GotoURL"] = "~/Register/Login.aspx";
                Session["Info"] = "对不起，您目前为游客，请返回登录";
                Response.Redirect("~/Register/MessageBox.aspx");
            }
        }

        /// <summary>
        /// 修改用户信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            //获取指定UserID的用户密码
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
            string UserID = Request.QueryString["UserID"].ToString();
            string SQL = "SELECT User_Pwd FROM [User]  WHERE (User_ID = " + UserID + ")";
            string userPwd = cd.GetFirstValue(SQL);

            //对用户输入的密码加密
            string strPwd = EncryptStringClass.EncryptString(TextBox1.Text.Trim(), "49316349");

            //比对用户的密码输入,正确则操作
            if (userPwd == strPwd)
            {
                //性别选择
                string sex = "男";
                if (RadioButton1.Checked)
                {
                    sex = "男";
                }
                else
                {
                    sex = "女";
                }

                //新密码
                string newPwd;//新密码
                if (TextBox2.Text.Trim() != "")
                {

                    newPwd = EncryptStringClass.EncryptString(TextBox2.Text, "49316349");//加密
                }
                else
                {
                    newPwd = userPwd;
                }

                //替换textArea中的换行符
                string strBody = OperateHtml.ReplaceHtmlText(TextBox12.Text, "\r\n", "<br/>");

                //更新数据
                SQL = "UPDATE  [User] SET  User_Pwd ='" +
                    newPwd + "', 昵称 = '" +
                    TextBox4.Text + "', 性别 = '" +
                    sex + "', 年龄 = '" +
                    TextBox5.Text + "', 籍贯 = '" +
                    TextBox6.Text + "', 电话 = '" +
                    TextBox7.Text + "', IM = '" +
                    TextBox8.Text + "', Email = '" +
                    TextBox9.Text + "', 个人主页 = '" +
                    TextBox10.Text + "', 自我介绍 = '" +
                    strBody + "', 密保问题 = '" +
                    DropDownList1.Text + "', 密保答案 = '" +
                    TextBox13.Text + "'  WHERE   (User_ID = " + UserID + ")";
                cd.RunSqlCmd(SQL);

                //跳转到指定页面
                Session["GotoURL"] = "~/Register/UserInfo.aspx";
                Session["Info"] = "成功更新用户信息";
                Response.Redirect("~/Register/MessageBox.aspx");

            }
        }
    }
}
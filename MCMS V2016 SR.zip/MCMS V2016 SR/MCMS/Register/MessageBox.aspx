﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Register/Register.Master" AutoEventWireup="true"
    CodeBehind="MessageBox.aspx.cs" Inherits="MCMS.Register.WebForm4" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <!--倒计时-->
    <script type="text/javascript">
        var second = 5;
        var timer;
        function change() {
            second--;
            if (second > -1) {
                document.getElementById("second").innerHTML = second;
                timer = setTimeout('change()', 1000);
            }
            else {
                clearTimeout(timer);
            }
        }
        timer = setTimeout('change()', 1000);
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div style="height:200px;padding-top:150px; text-align: center; vertical-align:middle;line-height:30px;">
        <asp:Label ID="Label2" runat="server" Text="[成功/失败]"></asp:Label>
        ，将在&nbsp;<strong><span id="second">5</span></strong>&nbsp;秒后自动跳转到指定页面。<br />
        <asp:Button ID="Button1" runat="server" Height="26px" OnClick="Button1_Click" 
            Text="点击按钮手动跳转" Width="187px" />
    </div>
</asp:Content>

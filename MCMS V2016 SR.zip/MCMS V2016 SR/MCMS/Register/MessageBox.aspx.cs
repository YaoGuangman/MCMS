﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Register
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //定时跳转到指定页面
            string info = Session["Info"].ToString();
            Label2.Text = info;

            //自动跳转到页面
            string goUrl = Session["GotoURL"].ToString();
            HtmlMetaView(this.Page, goUrl.Substring(1));   
        }

        /// <summary>
        /// 跳转到页面
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click(object sender, EventArgs e)
        {
            string goUrl = Session["GotoURL"].ToString();
            Response.Redirect(goUrl);
        }

        /// <summary>
        /// 定时跳转(方法)
        /// </summary>
        /// <param name="page">当前页面</param>
        /// <param name="_url">跳转到的页面</param>
        public static void HtmlMetaView(System.Web.UI.Page page, string _url)
        {
            System.Web.UI.HtmlControls.HtmlMeta reflash = new System.Web.UI.HtmlControls.HtmlMeta();
            reflash.HttpEquiv = "Refresh";
            reflash.Content = "5;url=" + _url;
            page.Header.Controls.Add(reflash);
        }
    }
}
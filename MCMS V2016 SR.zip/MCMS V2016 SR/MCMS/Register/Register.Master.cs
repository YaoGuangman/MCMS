﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Register
{
    public partial class Register : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = DateTime.Now.Year.ToString();
            //读取cookie,如果用户保存了登录信息则自动登录且保存到session
            if (Request.Cookies["UserName"] != null)
            {
                //保存用户信息为缓存
                Session["UserName"] = Request.Cookies["UserName"].Value;
                Session["UserPwd"] = Request.Cookies["UserPwd"].Value;
            }
        }
    }
}
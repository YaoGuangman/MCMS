﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Register
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 注册会员
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            //性别选择
            string sex = "男";
            if (RadioButton1.Checked)
            {
                sex = "男";
            }
            else
            {
                sex = "女";
            }

            //密码加密
            string strPwd = EncryptStringClass.EncryptString(TextBox2.Text.Trim(), "49316349");

            //替换textArea中的换行符
            string strBody = OperateHtml.ReplaceHtmlText(TextBox12.Text, "\r\n", "<br/>");

            //增加数据记录
            string SQL = "INSERT INTO [User](User_Name, User_Pwd, Role, 昵称, 性别, 年龄, 籍贯, 电话, IM, Email, 个人主页, 自我介绍, 密保问题, 密保答案 )VALUES ('" +
                TextBox1.Text + "', '" +
                strPwd + "', " +
                0 + ", '" +
                TextBox4.Text + "', '" +
                sex + "', '" +
                TextBox5.Text + "', '" +
                TextBox6.Text + "', '" +
                TextBox7.Text + "', '" +
                TextBox8.Text + "', '" +
                TextBox9.Text + "', '" +
                TextBox10.Text + "', '" +
                TextBox12.Text + "', '" +
                DropDownList1.Text + "', '" +
                TextBox13.Text + "')";

            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
            cd.RunSqlCmd(SQL);

            //跳转到指定页面
            Session["GotoURL"] = "~/Register/Login.aspx";
            Session["Info"] = "成功注册为会员,用户名:" + TextBox1.Text + " 密码：" + TextBox2.Text;
            Response.Redirect("~/Register/MessageBox.aspx");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MCMS.Register
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 找回密码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            //获取用户的密保问题，答案 和密码
            CData cd = new CData(@Server.MapPath("/App_Data/WebsiteDBS.mdb"));
            string SQL = "SELECT 密保问题 FROM [User] WHERE (User_Name = '" + TextBox1.Text + "')";
            string questionPwd = cd.GetFirstValue(SQL).ToString();

            SQL = "SELECT 密保答案 FROM [User] WHERE (User_Name = '" + TextBox1.Text + "')";
            string answerPwd = cd.GetFirstValue(SQL).ToString();

            SQL = "SELECT User_Pwd FROM [User] WHERE (User_Name = '" + TextBox1.Text + "')";
            string strPwd = cd.GetFirstValue(SQL).ToString();

            //密码解密
            string userPwd = EncryptStringClass.DecryptString(strPwd, "49316349");

            //验证密保问题，并发送用户密码
            if (questionPwd == DropDownList1.Text && answerPwd == TextBox12.Text)
            {
                //提示
                //跳转到指定页面
                Session["GotoURL"] = "~/Register/Login.aspx";
                Session["Info"] = "你好，你的用户名为：" + TextBox1.Text + " 密码为：" + userPwd;
                Response.Redirect("~/Register/MessageBox.aspx");
            }
            else
            {
                //提示
                //跳转到指定页面
                Session["GotoURL"] = "~/Register/FindPwd.aspx";
                Session["Info"] = "输入的密保问题或答案错误";
                Response.Redirect("~/Register/MessageBox.aspx");

            }
        }
    }
}
﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Register/Register.Master" AutoEventWireup="true"
    CodeBehind="UserInfo.aspx.cs" Inherits="MCMS.Register.WebForm3" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" DataKeyNames="User_ID"
        DataSourceID="AccessDataSource1" EnableModelValidation="True" PageSize="1" Width="100%"
        GridLines="None" AllowPaging="True" ShowHeader="False">
        <Columns>
            <asp:TemplateField>
                <ItemTemplate>
                    <div class="register_item" style="text-align: center; background-color: #CCCCCC;">
                        <img src="../Images/Register/User.jpg" style="height: 143px; width: 145px; margin: 20px;" />
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            编号ID：
                        </div>
                        <div class="register_item_right">
                            <%#Eval("User_ID") %>
                        </div>
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            昵称：
                        </div>
                        <div class="register_item_right">
                            <%#Eval("昵称") %>
                        </div>
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            用户组：
                        </div>
                        <div class="register_item_right">
                            <%#Eval("Role") %>
                        </div>
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            密码保护：
                        </div>
                        <div class="register_item_right">
                            <%#Eval("密保问题") %>&nbsp;&nbsp;密保答案：*******
                        </div>
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            性别：
                        </div>
                        <div class="register_item_right">
                            <%#Eval("性别") %>
                        </div>
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            年龄：
                        </div>
                        <div class="register_item_right">
                            <%#Eval("年龄") %>
                        </div>
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            籍贯：
                        </div>
                        <div class="register_item_right">
                            <%#Eval("籍贯") %>
                        </div>
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            电话：
                        </div>
                        <div class="register_item_right">
                            <%#Eval("电话") %>
                        </div>
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            QQ:
                        </div>
                        <div class="register_item_right">
                            <%#Eval("IM") %>
                        </div>
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            Email:
                        </div>
                        <div class="register_item_right">
                            <%#Eval("Email") %>
                        </div>
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            个人主页：
                        </div>
                        <div class="register_item_right">
                            <%#Eval("个人主页") %>
                        </div>
                    </div>
                    <div class="register_item" style="border-bottom-style: dashed; border-bottom-width: 1px;
                        border-bottom-color: #C0C0C0">
                        <div class="register_item_left">
                            自我介绍：
                        </div>
                        <div class="register_item_right">
                            <%#Eval("自我介绍") %>
                        </div>
                    </div>
                    <div class="register_item" style="margin-top: 10px;">
                        <div class="register_item_left">
                            &nbsp;
                        </div>
                        <div class="register_item_right" style="text-align: right;">
                            <a href='ChangeInfo.aspx?UserID=<%#Eval("User_ID") %>'>
                                <img alt="" src="../Images/Register/p%20(2).png" style="border-style: none" /></a>
                            &nbsp; <a href="../Default.aspx">
                                <img alt="" src="../Images/Register/p%20(4).png" style="border-width: 0px; border-style: none;" />
                            </a>&nbsp; <a href="../Admin/Admin.aspx">
                                <img alt="" src="../Images/Register/p%20(6).png" style="border-width: 0px; border-style: none;" />
                            </a>
                        </div>
                    </div>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <PagerSettings Visible="False" />
    </asp:GridView>
    <asp:AccessDataSource ID="AccessDataSource1" runat="server" DataFile="~/App_Data/WebsiteDBS.mdb"
        SelectCommand="SELECT * FROM [User] WHERE ([User_Name] = ?)">
        <SelectParameters>
            <asp:SessionParameter Name="User_Name" SessionField="UserName" Type="String" />
        </SelectParameters>
    </asp:AccessDataSource>
</asp:Content>
